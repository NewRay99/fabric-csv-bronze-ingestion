# SM_WMPP_v16 repository update

## Current local entry point — 23 September 2026

This is the latest active WMPP model project (45 tables). Open
`SM_WMPP_v16.pbip`: its attached report now contains the complete RPT WMPP v16
dashboard, all 16 pages / 255 visuals, bookmarks, drill-through, images and the
common theme. `SM_WMPP_v16.Report/definition.pbir` retains the local
`../SM_WMPP_v16.SemanticModel` connection and the report keeps its own identity.
All 53 model files were preserved byte-for-byte during the report copy.

The older nested `../SM WMPP v16` project (37 tables) has been retired to
`../../retired/2026-09-23-local-report-consolidation/SM WMPP v16`.
The previous 10-page attached report is backed up in the same archive folder.
The original client-connected RPT project remains unchanged for later deployment.

Local report/model linkage does not create an offline data cache or remove the
client-access requirement for refreshing model partitions. Desktop opening,
rendering and refresh have not been verified here. The inherited Requirements
Complete card schema exception remains outstanding in both report copies.

This PBIP project is the repository-owned update of the immutable client
baseline `../MWPP Repo 20092026.zip`. It has not been refreshed against Fabric
or accepted in Power BI Desktop yet.

## Apply the data changes first

Update the client notebooks from the repository sources and run them in this
order:

1. `project X/00_setup_cfg.py`
2. the existing Bronze/Silver pipeline
3. `project X/04_gold_model.py`
4. `project X/05_gold_dimensions.py`

The new semantic objects depend on snapshot-month fields, provider response
evidence, the provider-home/category bridge, scoped provider KPI components
and the security/summary Gold tables created by those sources.

## Security prerequisite

Populate and approve these configuration tables before publishing the RLS
role:

- `monitoring.cfg_security_scope`
- `monitoring.cfg_user_scope_access`
- `monitoring.cfg_referral_scope`

Empty mappings intentionally return no detail. The unrestricted
`fact_referral_global_summary` contains no referral, person, provider,
authority or free-text identifiers, but small-number suppression and Build/
export permissions still require Information Governance approval.

## Model changes

- current `_Measures.tmdl` installed, including compatibility aliases;
- state Month-on-Month measures use `fact_referral_snapshot` through
  `dim_snapshot_month`;
- automatic date tables removed and Auto date/time disabled;
- all business relationships changed to single direction;
- direct current-referral-to-snapshot relationship removed;
- placement type connected to both referral facts;
- model storage normalised to Import;
- provider KPI component and home/category bridge tables added;
- dynamic `WMPP Dynamic Detail RLS` role added; and
- stale report bindings repaired.

The provider composite score remains intentionally absent until its weights,
SLA, minimum sample, evidence coverage and governance rules are approved.

## Repeatable reconciliation

If a fresh copy of the same v16 client export is staged in this directory,
rerun:

```powershell
python "project X/tools/reconcile_semantic_model_v16.py"
```

Then run `project X/tests/validate_semantic_model_v16_reconciliation.py` and
`project X/tests/validate_gold_report_model.py`. These static checks do not
replace a Fabric refresh, DAX reconciliation, Desktop save/open test or
identity-based RLS UAT.
