# WMPP report navigation

## Current assessment 30 September 2026

Current inventory: 58 semantic tables, 366 measures, 34 page definitions (12 visible), and 158 bookmarks. The current page names are Referral Explorer and Provider Explorer, with both referral and provider drillthrough routes. The 139 retained bookmarks are supplemented by 19 stage-only data bookmarks. The newest journey-strip rendering and click actions need Desktop acceptance. Earlier dated counts and implementation notes below are historical. This documentation update did not change or refresh the report/model.

See [current client status](../../../../client%20documentation/04_Data_and_Reporting/WMPP_CURRENT_STATUS.md).


## Current WIP storyboard — 29 September 2026

The current WIP navigation and scope are documented in [REPORT_STORYBOARD.md](REPORT_STORYBOARD.md). It supersedes the historical inventories below: 15 navigation pages now use Home → Performance → Referrals → Offers → Draft offers → IPAs → Providers → Requirements, with repositioned expandable menus. Geography, Snapshots and the duplicate original single-view page are hidden and recoverable. Eight legacy bookmark IDs are redirected to valid Referrals actions. Desktop rendering and model runtime validation remain pending.

## Regular dropdown text — 28 September 2026

All 272 dropdown rows across 16 pages now use regular-weight text in default, hover, selected and disabled states, including Close menu. The shared dropdown preset is updated in all four current theme copies. Main navigation buttons, colours, sizes, spacing and bookmark actions are unchanged. Backup and inventory: `DROPDOWN_REGULAR_TEXT.json`; Desktop appearance is not verified.

## Typography refinement — 28 September 2026

Seven section headings changed from 32pt to 24pt. Card/Heading 4 labels, including the refresh label, now use regular weight. Small chart headings and supporting text at 13pt or below are also regular, including local bold/Semibold overrides. Current and reusable themes carry these defaults. Large numeric callouts, navigation styles, bookmark definitions, visual positions, queries and filters are preserved. Backup and inventory: `TYPOGRAPHY_REFINEMENT.json`. This is a saved-file change, not a claim of Desktop-render verification; unrelated field-binding errors are outside this formatting update.

## Filters colour — 28 September 2026

All 20 open/close Filters controls on the 10 dashboard pages use the owner's `#2B2427` choice in all native states. The white filter artwork, white panel, main navigation colours, sizing and bookmark actions are unchanged. Both filter-specific presets are updated in the embedded theme, brand master and reusable theme copies. Backup and scope: `FILTER_CHARCOAL_UPDATE.json`. Reload the saved project to see the embedded theme change; Desktop rendering is not verified.

## Current correction: white connected open-menu buttons

The cream rectangle was the primary button's opaque `#F8F5F1` fill covering its white surround. Each of the 64 existing menu-cap visuals now renders a white-backed native button at z=400010, using its existing ID and bookmark visibility. Original main buttons remain unchanged and visible underneath; the retired replacement variants remain hidden. The cap uses the same state artwork, shifted within its 104×116 target by (4,8), preserving the icon, circle and label screen positions and 9px capsule headroom. Its white fill joins the existing white neck and dropdown. Clicking the open cap closes the menu. Filters and navigation retain the cap's prior show/hide states.

Backup: `../_review/white-menu-join-20260928-135033/`; inventory: `WHITE_MENU_JOIN_REPAIR.json`. The current theme and reusable copies include `WMPP Connected Open Menu`; four connected background SVGs are registered and saved in the brand pack. Model files, report data visuals and original primary buttons are unchanged. Saved-file verification does not certify Desktop rendering; reopen the PBIP without overwriting it from a stale session.

## Current correction: headroom above the circle; original button stays visible

The requested space is above the orange circle inside the peach capsule, not an offset of the white glyph inside the circle. Active/hover SVGs now place the circle centre at y=42 (radius 31, capsule top y=2), producing 9px of headroom. Their 32px glyphs/native icons start at y=26. Resting/disabled circles retain centre y=36 with glyph/icon top y=20. Every glyph is centred inside its circle; labels and button target positions are unchanged.

The Referrals open-menu bookmark explicitly hid its original main button. The replacement-button swap is now withdrawn across all pages: all 128 primary buttons remain visible, while all 64 alternate open-menu buttons remain hidden in every bookmark. Use the existing Close menu row to close a dropdown. This supersedes the white-fill join approach below; seamless white joins are not asserted.

Backup: `../_review/capsule-headroom-20260928-133939/`; inventory: `CAPSULE_HEADROOM_CORRECTION.json`. One-off checks passed for 128 persistent primary buttons, 64 retired variants and all 36 SVG assets; 260 changed report/theme JSON files passed their published Microsoft schemas. Semantic-model definitions, visual positions, queries, filters and existing action targets are unchanged. These are saved-file checks, not Desktop-render acceptance. Reopen the saved PBIP without saving a stale open session over it.

## Superseded finish: dropdown highlights, white joins and icon position

All 272 dropdown rows use peach `#FCA356` for current-page, hover and pressed highlights, with white resting rows and dark text. The old coral/pink row overrides are removed. White icon glyphs are 4px lower in all 32 complete SVG variants and in the 128 native main buttons (top inset 24px); circle positions, labels and target dimensions are unchanged.

The warm-looking sliver came from an opaque canvas-colour main button over the white dropdown surround. Each expandable main button now has an initially hidden open-menu variant with white outer fill. Existing display-only bookmarks show this variant while hiding the ordinary button, then restore the ordinary button when closing/navigating/opening Filters. Exactly one of each pair is visible. Clicking an open main button closes its menu; the existing Close menu row remains available. No formatting-only bookmark behaviour is assumed.

The prior spacing pass also accidentally moved the Referrals journey toggle when iterating all visible bookmark buttons. Its original x=690, y=424 position has been restored; submenu resizing is now limited to submenu-row layers.

Backup: `../_review/menu-finish-20260928-133039/`; inventory: `NAVIGATION_MENU_FINISH.json`. One-off saved-state checks cover all 64 menu pairs, 272 rows, icon offsets and bookmark destinations. Model definitions, queries, slicer selections and existing button action targets are unchanged. The current theme and reusable theme copies include the open-menu and dropdown presets. Desktop rendering remains unverified; reopen the saved PBIP without saving a stale session over it.

## Current correction: orange states, wider labels and dropdown layering

The screenshot defects were reproduced in the saved configuration: the active background still contained coral/pink, every button was only 72px wide, and the white dropdown surrounds had a higher z-order than their main buttons. The one-off check failed before repair and passed afterwards across all 128 buttons / 16 report pages.

All enabled navigation states now use orange `#EF7911` circles; active, hover and pressed capsules use peach `#FCA356`. Targets are 96×108px at x=860 + 100×index, y=8. White icons are 32px with a 20px top inset. Native 8pt labels have their own lower area (top margin 74px; bottom 8px; sides 6px), giving Requirements 84px of text width. The primary buttons now sit above all dropdown surround shapes, preventing the white cap from covering the icon when its menu opens. Dropdown rows start at y=136.

Filters moves left with the wider row to x=748, y=0; its drawer starts at x=438, y=124. The changes are consistent across pages. No page content, queries, model definitions, action targets or bookmark visibility behaviour was changed. The current theme and reusable theme copies use the updated icon/text spacing.

Backup: `../_review/bubble-spacing-20260928-130700/`. Inventory: `BUBBLE_SPACING_REPAIR.json`. Of 627 checked JSON files, 588 passed their published Microsoft schema; 39 newer-version files passed a compatibility-only check against the available older schema. Actual newer schema declarations remain unchanged. File checks do not certify Desktop rendering; reopen the saved PBIP and verify hover, long labels, and each dropdown. Earlier geometry/colour details below are historical.

## Owner-selected bubble states — 28 September 2026

All 128 primary navigation buttons across the 16 navigable pages now use the owner's Home SVG colour treatment: resting Main Orange `#EF7911`, hover peach `#FCA356` capsule around orange, and current-section/pressed blush `#FEE1DD` capsule around coral `#FB6540`. White Lucide icons remain separate native icons in every state. There is no connecting bar and no change to page wallpaper, KPI icons or Filters utility-button styling.

Targets are 72×96px at x=1069 + 74×index, y=8, preserving the previously aligned circle centres. The capsule appears downward within that fixed target, without moving neighbouring buttons. Native labels are inside each button; the old separate labels are hidden in all bookmarks to avoid duplicates or interception of hover. The correct section is highlighted on each page, including Referral Overview. This is a state swap, not a smooth stretch animation.

The current theme and both reusable report-template copies include `WMPP Owner Bubble Navigation`. The report embeds icon-free background SVGs with fill transparency 0%, while using the existing direct white Lucide resources. The owner's supplied Home hover/active source files are unchanged. The new peach colour is recorded in the exclusive brand palette.

Backup: `../_review/owner-bubble-states-20260928-125437/`. Inventory: `OWNER_BUBBLE_NAVIGATION.json`. All 387 changed schema-bearing JSON files passed Microsoft schema validation. Semantic-model files, data bindings, navigation actions and non-navigation visuals are unchanged; bookmark modifications only keep superseded caption layers hidden. Desktop hover/render acceptance is still required after reopening the project. Do not save an older open session over these saved files.

## Current layout — 28 September 2026

The geometry and standalone-caption details in this earlier entry are superseded by the bubble-state section above; drawer positions and actions below remain current.

All 16 navigable report pages use the same header coordinates on their 1680px canvases: the first navigation circle starts at x=1072, y=8; all circles are 66px with a 74px pitch. Captions start at y=77. The separate white-icon coral circles and connected white dropdown surrounds are retained; no orange rail or page skin has been added. Guide and tooltip pages keep their context-specific return controls.

The Filters control sits immediately left of the navigation at x=960, y=0 (88×104px). Its drawer opens below and to the left, at x=650, y=112, with 24px content insets. Main navigation remains visible because it no longer overlaps the drawer. Opening a submenu closes Filters; opening Filters closes submenu rows/surrounds. Display-only bookmarks preserve current data selections and do not change pages.

Collapsible drawers are provided on Referrals, Referral Overview, Offers Overview, Draft Offers, IPA Overview, Requirement Matrix Overview, Board Dashboard, Provider & Placement Supply, Target & Urgency Performance and Referral Snapshots. Existing slicers have been moved rather than duplicated. Requirement Matrix receives initially unfiltered date and placement-type controls using the existing model fields. The Snapshot Window selector remains beside its chart. Single-record, drill-through and geography/location pages retain visible slicers. Home remains a landing page without an unnecessary filter drawer.

Referrals now has **Explore referral journey →** above the KPI area. It opens a white rounded overlay containing a copy of the native Sankey from Referral Overview, with its exact source/target/count query preserved. **Close referral journey ×** restores the KPI view. The source chart remains on Referral Overview. Menu and filter actions close the journey overlay; none refresh data or change model relationships.

Bookmark labels now use readable page/action names, for example `Referrals | Open filters`, `Referrals | Show referral journey`, and `Board Dashboard | Offers menu`. Internal bookmark identifiers are retained. Referral Overview's copied header now uses page-local menu bookmarks rather than Board Dashboard's. The removed original-single-referral menu destination has been replaced with Referral Overview; legacy bookmark IDs still resolve to the current single-referral page.

Backup: `../_review/aligned-navigation-20260928-124219/`. Inventory: `NAVIGATION_LAYOUT_DELIVERY.json`. Existing queries, slicer selections, visual filters and semantic-model files are preserved. No semantic/report-version test suite was added or run. One-off checks cover saved geometry, bookmark targets, drawer states and the journey show/hide pair. Microsoft schema validation passed for 910 changed files; 44 retain Desktop's newer visual-container 2.12.0 schema, whose public schema URL currently returns 404. These are not claims of rendered acceptance: Desktop capture failed with `FrameArrived timed out` and `window capture timed out`.

Reopen `SM_WMPP_v16.pbip` to load the saved files. Do not save a stale open Desktop session over this delivery. Review Filters → Close, each submenu, and Referrals → Explore referral journey → Close, checking that slicer selections remain applied.

## Previous Filters repair — superseded by the layout above

The Filters actions on Referrals, Offers Overview, Draft Offers and IPA Overview now use page-local, selected-visual, display-only bookmarks. Opening Filters hides the main menu/captions and all dropdown rows/surrounds; closing it restores the main menu without reopening dropdowns. The filter group and close control sit above the navigation layer. The previously retired orange rail remains hidden.

The prior filter bookmarks captured a whole page and sat below newer navigation. Three buttons also linked to a legacy Geography-page bookmark whose filter group no longer existed. Those pages now have local copies of the existing date and placement-type controls, initially unfiltered; the original Referrals slicer definitions and selections remain unchanged. No new measure, model relationship or report-wide filter was added. Opening/closing the drawer neither changes the current page nor restores saved data selections.

Navigation arrival bookmarks also collapse the repaired drawers and restore the main menu. The old filter bookmark IDs remain as scoped Referrals aliases, rather than stale Geography snapshots. The source ZIP and other projects are unchanged.

Backup: `../_review/filter-navigation-20260928-115341/`. Inventory: `FILTER_NAVIGATION_REPAIR.json`. The focused bookmark contract check failed before repair and passed after; 51 changed JSON files pass Microsoft schema checks and all referenced visuals/groups resolve. Existing visual queries, visual filters and semantic-model files are preserved. No semantic/report-version pytest suite was added. These checks do not constitute Desktop rendering or data-interaction acceptance: reopen the saved PBIP and confirm Filters → Close on each of the four pages, with a slicer selection retained.

Updated 27 September 2026. Open `SM_WMPP_v16.pbip` in this folder. These changes are saved locally in its attached report; nothing has been published or refreshed.

## Current correction: native icons, neutral wallpaper and title-case labels

The experimental bubble bar is withdrawn. All 128 main buttons once again use the direct native custom-icon configuration with white Lucide artwork on separate 66px coral circles. The 16 connecting orange rails are hidden and their resources retained for recovery; the captions beneath the buttons are visible. No fill-image state is required to display the icons. Dropdown actions and white surrounds are retained.

The owner screenshot also showed orange outside the canvas. All 33 pages now explicitly use `#F8F5F1` for wallpaper, matching the canvas and theme defaults. Page names and guide suffixes are title case, preserving WMPP and IPA. The original referral detail view is labelled `Referral Single View (Original)` to avoid duplicate names. Internal page IDs, bookmarks, queries and filters are unchanged.

Backup: `../_review/menu-correction-20260927-202435/`; inventory: `MENU_CORRECTION.json`. The one-off configuration check failed before correction (128 disabled direct icons, 16 visible rails, 31 non-neutral wallpaper configurations and 23 page names requiring case changes), then passed. Microsoft schema validation passed for 549 changed report definitions and four current themes. This is not Desktop visual acceptance and no semantic/report-version pytest suite was added.

Reopen the saved project to inspect the icons, neutral outer background and names. Do not save an older open Desktop session over these changes. The previous bubble implementation remains documented below as history only.

## Superseded design: horizontal bubble bar

All 16 main pages now share a horizontal coral rail with white Lucide icon bubbles. The current section has a blush capsule; hovering expands a rounded coral highlight down around the icon and its always-visible native label. This supersedes the separate circular buttons described in the historical entries below. The effect is a native fill-image state change, not continuous animation.

The 128 button actions and existing menu bookmarks are unchanged. Referral, Offer, Provider and Performance menus still open only their own subpages. The dropdown rows on the added pages have moved down 14px to clear the expanded bubbles. Hidden guide-page navigation, filters, chart queries, model files and report content are unchanged. Superseded standalone captions remain hidden and recoverable; captions are now part of the clickable native button.

The master `WMPP_Theme.json`, both template copies and the embedded theme include a `WMPP Bubble Navigation` preset. The 32 SVG state resources are embedded and also saved under `assets/brand-pack/icons/navigation-bubbles` at the Project X root. No new colours were introduced. Importing the theme alone does not install navigation assets or actions.

Backup: `../_review/bubble-navigation-20260927-201804/`. Implementation inventory: `BUBBLE_NAVIGATION.json`. Microsoft schema validation passed for 741 changed report definitions and four custom themes. Non-navigation report definitions, bookmarks and semantic-model files were checked unchanged; no report-version/semantic pytest suite was added or run.

**Desktop acceptance is still outstanding:** reopen the saved PBIP, inspect labels and hover states, then Ctrl+click each menu group and its Close entry. Confirm the current section is highlighted and filters remain unchanged. These are saved-file and schema checks, not a claim of successful Desktop rendering.

## Menu

A compact row of original-style circular buttons connects all 16 main pages. The earlier two-row menu has been replaced. The active area is highlighted; full captions sit below the abbreviated buttons. Original page names remain capitalised.

All 128 main navigation buttons now explicitly use the original report's native oval shape definition (`tileShape: oval`, `roundEdge: 84L`) with a state selector for default, hover, selected and disabled states. Each retains equal 66-pixel width and height. The earlier unscoped shape entry is replaced; dropdown rows, surrounds, actions, captions and positions are unchanged. Original button files are backed up under `../_review/circular-navigation-20260927-154439/`. Saved-file checks confirm that only these shape definitions changed; Desktop rendering remains unverified.

- `HO` Home, `DO` Draft offers, `IO` IPAs and `RM` Requirements open their pages directly.
- `R` Referrals, `OO` Offers, `PR` Providers and `PF` Performance reveal only their own related pages in a dropdown below the navigation.
- Opening another category closes the previous dropdown. Each dropdown has a Close menu entry. Selecting a destination closes the menu overlays and opens that page.
- On the original branded overview pages, the circles occupy the original header navigation area; the added 104-pixel menu band is removed. Pages without that header retain a dedicated navigation band so their titles and charts are not covered when menus are closed.
- Expanded dropdowns temporarily overlay the content below; they are not always-visible extra rows. Close the menu to inspect that content.
- Each open dropdown now has a continuous white surround: a rounded panel with 12-pixel outer padding, connected to a white surround behind its circular main button. The yellow annotation in the reference was a markup guide only; no yellow is used. The panel has the existing subtle rose-grey shadow. These editable native shapes open/close with their own dropdown and remain hidden otherwise; main buttons, captions and submenu rows are unchanged.

| Area | Pages |
| --- | --- |
| Home | WMPP HOMEPAGE |
| Referrals | REFERRALS; REFERRAL SINGLE VIEW (original); Referral Single View (new explorer); Referral Geography; Referral Snapshots; REFERRAL DETAIL (DRILLTHROUGH) |
| Offers | OFFERS OVERVIEW; DRAFT OFFERS; Offer Locations |
| Providers | PROVIDER SINGLE VIEW; Provider & Placement Supply |
| IPAs | IPA OVERVIEW |
| Performance | Board Dashboard; Target & Urgency Performance |
| Requirements | REQUIREMENT MATRIX OVERVIEW |

The menu uses bookmarks scoped only to its own dropdown controls, with Data disabled. Open/close actions also disable Current page; destination actions change the page and hide dropdowns. No data selection is captured by these menu bookmarks. This follows Microsoft's [selected-visual bookmark guidance](https://learn.microsoft.com/en-us/power-bi/create-reports/desktop-bookmarks).

Navigating to a detail page does not select a record or automatically pass the current visual selection. Use the existing drillthrough action to carry referral context, or use the destination's search/filter controls. Confirm one referral or provider is selected before interpreting individual detail. In Power BI Desktop edit mode, follow action buttons with Ctrl+click.

## Original referral pages restored

The original `REFERRALS` and `REFERRAL SINGLE VIEW` pages from `reports/current/WMPP v16/RPT WMPP v16/WMPP_DASHBOARD_v16.Report` are restored as separate pages. Their former page IDs had been reused by the new geography and referral explorer pages; those newer pages are retained.

The restored pages preserve source queries, visual filters, groups and interactions. Required embedded resources and the original referral filter-panel bookmarks were copied with separate identifiers. They use the current plain canvas and native panel styling, not the old full-page background skin.

Grouped content moves by its parent container, preserving child positions. Superseded page-navigation controls are hidden; chart-view, filter-panel and help controls remain. Hidden guide pages retain their existing return links.

## Verification and backup

- All menu bookmark and page destinations resolve; all 64 dropdown-open states show only their category's entries plus Close. Buttons explicitly enable text at the visual level and provide labels for default, hover, selected and disabled states, following the original saved button format.
- The dropdown revision passed Microsoft schema checks; the white-surround follow-up adds only native shape visuals and their visibility entries in existing menu bookmarks. See its backup verification record for the latest checks.
- Restored source visual queries and filters match; semantic-model files are unchanged.
- No semantic-model or report-version pytest suite was created or run.
- The user's supplied screenshot confirms that the referral dropdown text is now visible. The new white surround, other-page rendering, slicer behaviour and drillthrough execution still require Desktop inspection; schema checks do not prove rendering or data correctness. Earlier Desktop capture failed twice (FrameArrived/window capture timeout).

The original pre-menu report definition and resources are backed up in `../_review/navigation-20260927-143541/`. The complete pre-dropdown definition is in `../_review/dropdown-navigation-20260927-145844/`, with the 168 removed two-row menu visuals retained under `retired-menu/`. Both backups include `verification.json`.

The pre-surround definition is backed up in `../_review/dropdown-surround-20260927-150837/`. This follow-up preserves every existing page/visual file byte-for-byte and leaves semantic-model files unchanged. Only new surround shapes and menu-bookmark entries are added.

Reopen this saved project in Desktop to inspect the revision. Do not save an older open Desktop copy over these file changes. Check that R shows the six referral destinations, OO shows only the three offer destinations, Close hides the list, and date/category selections remain unchanged after opening or closing menus.

## Coral colour revision — 27 September 2026

All 128 main navigation buttons now use `#FB6540`, charcoal labels and lighter
coral hover; a deep-coral outline identifies the current area. The 272 dropdown
row/close buttons use matching coral/soft-coral states with readable dark text.
White dropdown surrounds, native oval geometry, positions, bookmarks and query
definitions are unchanged. The existing card glow and page background remain.

The original rose fills were saved visual overrides, so changing a theme alone
did not update them. Both overrides and the embedded/shared themes have now been
updated. See `assets/brand-pack/WMPP_Brand_Pack.md` at the Project X root for the
extended palette and its contrast rules.

The four pre-change theme files and 400 changed button files are recoverable in
`../_review/coral-palette-20260927-162231/`, with a verification record. Semantic
model files and `WMPP_Theme_v0.json` were hash-checked unchanged. Desktop rendering
still needs inspection after reopening the saved project; do not save an older
open copy over the updated files.

## Lucide navigation icons — 27 September 2026

The main-button initials are replaced by eight white Lucide SVGs on all 16 main
pages (128 buttons). Main-button outlines and borders are disabled, superseding
the deep-coral outline described in the earlier colour revision above. Captions,
tooltips, existing coral fills, positions, circular shapes and bookmark actions
are preserved. Dropdown rows and the separate Filters control are unchanged.

Native button custom icons are used, with a 32px icon-size setting and explicit
default/hover/selected/disabled states. No image overlays intercept clicks.
Resources are embedded in the report; `LUCIDE_NAVIGATION_SOURCES.json` and
`LUCIDE_LICENSE.txt` in this project root provide audit/licence details. Master
assets and unmodified source SVGs are in `assets/brand-pack/icons` at Project X root.

Prior button files, report resource registration and themes are backed up in
`../_review/lucide-navigation-20260927-164358/`. Saved-file checks preserve model
and bookmark contents; Desktop rendering remains unverified. Reopen the saved
project without overwriting it from an older open Desktop session.

## Future edits

Treat navigation as the final report assembly step. Earlier whole-page layout/style builders contain fixed coordinates and may overwrite menus or mis-handle restored grouped visuals. Do not run them directly over this assembled delivery. The migrations `project X/tools/connect_wmpp_report_pages.py` and `project X/tools/use_wmpp_dropdown_navigation.py` intentionally refuse a second application; they are not in-place repeatable styling commands.
