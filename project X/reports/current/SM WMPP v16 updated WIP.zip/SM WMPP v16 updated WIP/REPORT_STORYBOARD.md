# WMPP report storyboard

## Current assessment 30 September 2026

Current inventory: 58 semantic tables, 366 measures, 34 page definitions (12 visible), and 158 bookmarks. The current page names are Referral Explorer and Provider Explorer, with both referral and provider drillthrough routes. The 139 retained bookmarks are supplemented by 19 stage-only data bookmarks. The newest journey-strip rendering and click actions need Desktop acceptance. Earlier dated counts and implementation notes below are historical. This documentation update did not change or refresh the report/model.

See [current client status](../../../../client%20documentation/04_Data_and_Reporting/WMPP_CURRENT_STATUS.md).


Updated 29 September 2026. Applies only to **SM WMPP v16 updated WIP**. The non-WIP delivery and shared brand templates were not overwritten.

## The user journey

**Home → Overall Performance → Referrals → Referral Single View → Referral Detail → Back to results**

| Step | The user's question | What the report provides | Next action |
|---|---|---|---|
| Home | Where should I begin? | Three entry cards: overall performance, referral dashboard and referral exploration | Choose an entry point |
| Overall Performance | How are we doing, what is changing, and what does it cost? | Existing executive indicators; month-end total/closed referral snapshots; month-on-month changes; closure flow; estimated active weekly cost by placement type | Open Referrals |
| Referrals | What needs operational attention today? | Current referral demand, engagement, overdue work and existing journey overlay | Open Referral Single View from the Referrals menu |
| Referral Single View | Which referrals explain the figures? | Persistent filters, priority/status/framework-category breakdowns and a referral results table | Right-click a Referral ID and choose Drill through → Referral Detail |
| Referral Detail | What has happened on this referral, and what options are available? | Referral facts, provider messages, ordered lifecycle events, offers with provider homes, assignment directory and provider/offer location map | Use Back to results to return to the prior cohort |

## Navigation

The order is **Home, Performance, Referrals, Offers, Draft offers, IPAs, Providers, Requirements**. Performance opens the menu containing Overall Performance and Target & Urgency Performance.

Main buttons, connected white open-menu caps, dropdown panels, necks and rows move together. Filters remain to the left. Existing bookmarks and visual IDs are retained; data filters are not deliberately reset by menu actions. The detail page is hidden from normal page tabs so the normal route is referral-key drillthrough.

The Referrals dropdown retains the referral dashboard, Referral Single View and Close menu. Geography and Snapshots no longer appear there. Their pages, plus the older duplicate single-view page, are hidden and recoverable rather than deleted. Snapshot reporting is now available on Overall Performance. The original detail and single-view body visuals are retained hidden for recovery.

## Referral exploration

Persistent filters cover:

- Referral priority and placement urgency band, kept separately pending the owner's decision.
- Framework category, using the existing category-to-referral bridge logic.
- Current referral status, is-open and is-open-overdue.
- Offer status and days since offer activity.

Offer filters select referrals with at least one matching offer; they do not introduce a bidirectional relationship. A referral can belong to several framework categories, so category counts are not additive.

The provisional non-overlapping activity bands are **0–3, 4–7, 8–14 and 15+ days**. Missing activity ages are **Unknown** and negative ages are **Review**. This resolves the overlap in the requested 0–3, 4–7, 7–14, 14+ labels without silently counting a boundary day twice. Owner confirmation is still requested.

Neither priority field is deleted or renamed in the semantic model. Their business equivalence has not been verified against actual values.

## Performance definitions

- **Total at snapshot:** distinct referrals in each retained snapshot month.
- **Closed states at snapshot:** the existing governed measure for closed, cancelled, withdrawn or completed referrals in that snapshot. This is not a count of closure events.
- **Closures during month:** distinct referrals with a recorded closure date in the calendar month; the created-date relationship is disabled only within this calculation.
- **Month-on-month progress:** snapshot total minus the prior month's snapshot total, with the percentage change shown separately. Missing prior-month data is not fabricated.
- **Cost breakdown:** estimated active weekly liability by required placement type, using the existing active-cost measure. This is not actual spend.

Both closed-state and closure-flow views are included so the two meanings remain explicit. Calendar/cohort filters and snapshot-month context are different; the captions distinguish them.

## Referral details and map

The detail page retains the existing `fact_referral.referral_id` drillthrough binding. A single-referral selector is available for recovery/manual inspection. Provider messages are linked through their referral-provider assignment; the added relationship does not enable bidirectional filtering.

Lifecycle rows are sorted by sequence. Offers include provider, proposed home, home postcode, status, estimated weekly cost and activity band. The map combines two point types:

| Colour | Point type | Meaning |
|---|---|---|
| Teal `#4DAAAB` | Assigned provider | Provider office postcode for a referral-provider assignment |
| Orange `#EF7911` | Offer home | Proposed provider-home postcode for an offer on the referral |

Only town/county/postcode fields exist in the inspected model; full street addresses and exact coordinates are not invented. Missing postcodes remain in the location directory but cannot be plotted. Multiple points may overlap at one postcode. No child home address is added. Map category colours follow the [Azure Maps legend/marker pattern](https://learn.microsoft.com/en-us/azure/azure-maps/power-bi-visual-add-bubble-layer).

The new map table is filtered by the existing referral table, including its row-level security path. Existing role definitions and permissions are unchanged. Role-based runtime verification is still required before publishing.

## Reusable styles

The WIP theme now has **15 named families instead of 133 presets**. Examples include WMPP KPI Card, WMPP Detail Table, WMPP Trend Chart, WMPP Filter and WMPP Navigation Button. Hash suffixes are removed from the selectable names.

Properties common to a family live in its shared preset. Intentional differences are retained as local overrides rather than flattened into an unrelated appearance. `STYLE_MIGRATION.json` records every old-to-new name. `WMPP_Theme.json` in this folder is the reusable WIP template; the embedded copy is also updated. The previously delivered global brand theme remains untouched.

## Acceptance before release

Saved-file checks passed: 2,151 report/theme JSON files against Microsoft schemas, 120 main navigation buttons and 60 expandable menus at their expected positions, and all 884 style references resolved (including the native Tile preset). Eight legacy bookmarks targeting an absent page were redirected to corresponding Referrals actions while preserving their IDs. These structural checks do not certify DAX results, security behaviour or rendered appearance.

The saved files have not been refreshed or published. Reopen this WIP project without saving an older open session over it, then refresh its model to populate the new calculated fields/table.

Check these interactions in Power BI Desktop:

1. Home entry cards and the reordered main menu; open/close every dropdown and Filters drawer.
2. Referral filters alone and together, including category and offer filters; verify one referral is counted once.
3. Drill through a known referral; confirm messages, events, offers, homes and map locations belong to it, then use Back.
4. Check activity boundaries 3/4, 7/8 and 14/15, missing ages and negative ages.
5. Reconcile at least two consecutive snapshot months and a known closure against source records.
6. Verify different security roles and map/tenant permissions before publishing.

Power BI engine validation and Desktop rendering are not yet confirmed. The installed parser was inaccessible, and connector-based offline model import was blocked pending owner approval. No connector-side import, data refresh or publication was completed.

The complete pre-change backup is recorded in `STORYBOARD_DELIVERY.json` under `../_review/wip-storyboard-20260929-233007/`.
