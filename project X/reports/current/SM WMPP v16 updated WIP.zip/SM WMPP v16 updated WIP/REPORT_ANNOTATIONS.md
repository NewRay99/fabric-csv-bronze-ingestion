# Native report annotations and icon audit

## KPI icons and colour revision — 27 September 2026

54 native KPI image slots and 22 standalone pictograms now use transparent
Lucide SVGs. There are 119 matching guide icons and 17 added subpage heading
icons. All 85 information-badge visuals retain their existing appearance,
including their pale backgrounds. White navigation icons are unchanged.

The provider ranking on OFFERS OVERVIEW uses coral bars instead of its rose
gradient. Thirty charts received palette updates. Card surfaces, padding,
rounded corners and soft shadows remain. Guide headings are inset beside icons;
three missing requirements-card explanations were added without changing or
certifying the underlying calculations.

See `LUCIDE_KPI_SOURCES.json` for the per-visual mapping and source hashes.
Master SVGs, original downloads and usage notes are in the brand-pack icons
folder. Retain the Lucide licence notices supplied in this project root.

Before-change files: `../_review/kpi-icons-colours-20260927-170651/`. Queries,
reference measures, filters, actions, model files and bookmarks are preserved.
No model tests, refresh or publication were performed. 1,937 report documents
and four themes passed available schema checks. Five pre-existing visuals use
the unpublished 2.12.0 schema and could not receive that schema check. New icons
resolve to embedded resources and fit page bounds. Desktop appearance remains
unverified.

Updated 27 September 2026. Changes are local to the semantic-model-attached delivery report; no publication or model edits.

## Styling

The light canvas is `#F8F5F1`. Rounded cards and chart panels retain a native soft glow: rose-grey `#B78D98`, 80% transparency, 14px blur and 4px downward offset. Dark panels use a black shadow at 70% transparency. These are separate editable native panels, not background skins; headings and icons do not cast shadows. Saved in the shared theme as `WMPP Soft Glow` / `WMPP Soft Panel` presets. Desktop appearance still requires visual inspection.

Plain page colours; no visible composite skin. Editable Segoe UI headings and captions, borderless annotations, zero outer padding. Existing chart colours, filters, measures, bookmarks and drillthrough bindings are retained. The light WMPP and dark Mission Control palettes remain distinct.

Visible pages and the job drillthrough page have a How to read this page footer linking to a hidden native guide. The Board retains its existing header/section guide buttons. Footer space is added below existing visuals, not over them. Compact tooltip/helper pages are styled in place.

## Icons

Source: https://lucide.dev/icons/ — official lucide-icons/lucide revision `66d8f9fc394b8530377e5f6112f0b8908ba01280`.

The upstream `lucide-*.svg` originals now live in `project X/assets/brand-pack/icons/lucide-originals`; `lc-*-ink.svg` / `lc-*-light.svg` variants are in `icons/report-variants` in that shared pack. See its migration manifest for exact version mappings. The exact variants used by Power BI are also embedded as registered report resources. No API key is required.

See `Lucide-provenance.json` for each source URL and SHA-256; retain `Lucide-LICENSE.txt` with client deliveries, including the ISC and applicable Feather/MIT notices.

## Verification and acceptance

One-off JSON/schema, layout bounds and preservation checks are used; no report-version-specific or semantic-model test suite is added. Native Power BI Desktop rendering, interaction and client refresh still require inspection. Older layout renders do not show this revision.

## Navigation and restored originals

Original-style circular navigation now connects all 16 main WMPP pages, including the capitalised original pages and newer overview/detail pages. Referrals, Offers, Providers and Performance open category-specific dropdowns underneath; the earlier blank two-row menu is retired to the backup. Original `REFERRALS` and `REFERRAL SINGLE VIEW` are restored separately from the newer geography and referral explorer pages. See `REPORT_NAVIGATION.md` for the page map, drillthrough guidance, backup and verification limits. Semantic-model files are unchanged. Desktop text rendering and interaction acceptance remain outstanding.

## Page context

### REFERRALS / REFERRAL SINGLE VIEW (original)

These retain the original RPT report queries, filters and visual groups. Use the referral filter controls and original single-view search to establish the record/cohort. The separate newer referral explorer remains available from the same Referrals menu.

### PROVIDER SINGLE VIEW

Search for a provider, then inspect its recorded homes, assignments and offers. Confirm the selection before comparing providers; relationship directions determine which visuals respond.

### Offer Locations

Compare the available preferred-city-to-provider-home distances and their coverage. These are not exact child-address distances, road travel distances or journey-time estimates. Missing locations remain unknown.

### OFFERS OVERVIEW

Review the current offer workload and provider engagement. Referrals, offers and provider assignments are different units; use each metric's definition rather than adding the cards together.

### WMPP HOMEPAGE

Choose a report page to explore referrals, offers, providers and placement performance. Check source refresh/as-of dates before using the figures operationally.

### REFERRAL DETAIL (DRILLTHROUGH)

Inspect the referral context carried by drillthrough. Search by referral ID or person label and review related offer and IPA records; verify one referral is selected before interpreting individual detail.

### Provider & Placement Supply

Understand provider participation, the offers received and the homes represented. Counts describe filtered records, not a live vacancy register.

### IPA OVERVIEW

Review the recorded stages between successful offers and IPA completion. Stage counts describe current records, not necessarily one same-period conversion cohort.

### Target & Urgency Performance

See which placements are due, which open referrals are overdue and how eligible cohorts meet their required placement dates. Use the source as-of date when interpreting urgency.

### DRAFT OFFERS

Identify draft offers and recorded activity since creation. Age is not a service-level breach by itself; check the selected cohort and supporting records before acting.

### REQUIREMENT MATRIX OVERVIEW

Trace requirements to the documented KPI catalogue. These are catalogue records, not service caseload counts, and a mapping alone does not prove that a requirement has been delivered.

### Referral Snapshots

Compare retained month-end referral states across a 6- or 12-month window. Historical snapshots and the current referral state answer different questions.

### Referral Geography

Explore referral preference-city areas, not individual child addresses. Category and framework filters refine the cohort; breakdown and metric selectors change the comparison. Do not infer precise child locations from map circles.

### Referral Single View

Search by person label and referral ID, then inspect offers, provider referrals and IPA records. Check that one referral is selected. The map represents preference-city areas, not the child's home address.
