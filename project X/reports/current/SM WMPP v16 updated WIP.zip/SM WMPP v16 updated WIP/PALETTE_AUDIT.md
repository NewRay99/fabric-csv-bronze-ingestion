# WMPP approved palette audit

27 September 2026. The current authority is `project X/assets/brand-pack/WMPP_Brand_Pack.md`
with the exclusive 24-colour list in `WMPP_Palette.json`.

- Report formatting, saved visual/bookmark colours, registered theme copies,
  base-theme colour defaults, deployed SVGs and active brand CSS now use only
  approved authored colours. The final scan covered 2,060 files with no off-list
  hex literals.
- Residential is explicitly teal across placement-type donuts. Supported
  Accommodation is coral; Fostering is charcoal. Routine category charts no
  longer depend on the old pale-yellow override.
- Explicit theme shade expressions and continuous chart colour rules were
  removed in favour of declared palette colours. Default categorical colours
  repeat the approved sequence while retaining the original theme index count.
- Small information badges retain their pale background treatment using Soft
  Amber and Charcoal. Navigation stays white-on-coral, circular and borderless.
- All 28 KPI icon variants keep their 25% reduction; embedded copies and audit
  hashes agree. Filename suffixes are stable resource IDs, not current colour
  declarations: consult the colour field in `LUCIDE_KPI_SOURCES.json`.
- Queries, filters, navigation actions, layout coordinates, model files and the
  original fallback theme are unchanged by the migration.

## Verification limits

1,928 report documents and nine importable themes passed the available Microsoft
schemas. Fourteen existing visuals reference the unpublished 2.12.0 schema and
could not receive that schema check. The bundled base theme uses internal tokens
not fully covered by the custom-theme import schema; its colour literals were
checked against the same whitelist. No semantic-model tests, refresh or
publication ran. Desktop rendering remains unverified.

The colour rule covers authored styling, not every screen pixel. Client logos,
supplied raster images, map-provider imagery, antialiasing and transparency may
contain or produce other colours. Original upstream SVGs, archived mockups and
the historical fallback remain unmodified reference evidence. Dark Mission
Control is outside this WMPP revision.

## Recovery

Pre-change files are in `../_review/approved-palette-20260927-172447/`.
The theme-format follow-up has a separate backup at
`../_review/palette-theme-normalisation-20260927-172742/`.
Reopen the saved project for inspection; do not overwrite it from an older open
Desktop session.
