# Native report annotations and icon audit

Updated 27 September 2026. Changes are local to the semantic-model-attached delivery report; no publication or model edits.

## Styling

The light canvas is `#F8F5F1`. Rounded cards and chart panels retain a native soft glow: rose-grey `#B78D98`, 80% transparency, 14px blur and 4px downward offset. Dark panels use a black shadow at 70% transparency. These are separate editable native panels, not background skins; headings and icons do not cast shadows. Saved in the shared theme as `WMPP Soft Glow` / `WMPP Soft Panel` presets. Desktop appearance still requires visual inspection.

Plain page colours; no visible composite skin. Editable Segoe UI headings and captions, borderless annotations, zero outer padding. Existing chart colours, filters, measures, bookmarks and drillthrough bindings are retained. The light WMPP and dark Mission Control palettes remain distinct.

Visible pages and the job drillthrough page have a How to read this page footer linking to a hidden native guide. The Board retains its existing header/section guide buttons. Footer space is added below existing visuals, not over them. Compact tooltip/helper pages are styled in place.

## Icons

Source: https://lucide.dev/icons/ — official lucide-icons/lucide revision `66d8f9fc394b8530377e5f6112f0b8908ba01280`.

`lucide-*.svg` files in this project root are upstream originals. `lc-*-ink.svg` / `lc-*-light.svg` are report variants with only the stroke colour changed. The exact variants used by Power BI are also embedded as registered report resources. No API key is required.

See `Lucide-provenance.json` for each source URL and SHA-256; retain `Lucide-LICENSE.txt` with client deliveries, including the ISC and applicable Feather/MIT notices.

## Verification and acceptance

One-off JSON/schema, layout bounds and preservation checks are used; no report-version-specific or semantic-model test suite is added. Native Power BI Desktop rendering, interaction and client refresh still require inspection. Older layout renders do not show this revision.

## Page context

### Job Step Detail (Drillthrough)

Review the selected job and notebook steps with timestamps, durations and recorded errors. Some headline measures fall back to the latest job when no single job is selected; confirm the displayed run ID.

### Archive & Replay

Review archive batches, reload flags, attempts and month-end snapshot results. This is a read-only monitoring page: viewing or selecting a row does not run a replay.

### Load Calendar

Select a calendar day to filter the right-hand view. Switch between Day Gantt and Register without resetting that selection. Green indicates recorded success; red indicates failures, also identified by status text.

### Quality & Schema

Review evaluated data-quality checks, failed checks and failed-row counts alongside the captured schema. A row can fail several checks, so failed-row totals are not necessarily distinct affected records.

### Job & Step Timelines

Choose a job to inspect its steps. Runtime bands describe comparable successful history: previous 30 days, at least five samples, P25–P75 with a mean marker. They are not SLAs or prediction intervals; failed endpoints carry a red halo and status label.
