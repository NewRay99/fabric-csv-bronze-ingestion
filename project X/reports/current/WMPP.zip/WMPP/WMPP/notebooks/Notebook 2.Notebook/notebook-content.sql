-- Fabric notebook source

-- METADATA ********************

-- META {
-- META   "kernel_info": {
-- META     "name": "synapse_pyspark"
-- META   },
-- META   "dependencies": {
-- META     "lakehouse": {
-- META       "default_lakehouse": "d286fa39-f255-4ba7-a982-32cb69362ef7",
-- META       "default_lakehouse_name": "LH_BCT_WMPP",
-- META       "default_lakehouse_workspace_id": "fefdb483-d26c-4bd9-9a4f-0c41cc786770",
-- META       "known_lakehouses": [
-- META         {
-- META           "id": "d286fa39-f255-4ba7-a982-32cb69362ef7"
-- META         }
-- META       ]
-- META     }
-- META   }
-- META }

-- CELL ********************


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.monitoring.cfg_schema_definition_candidate --where table_name like '%doc%' LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.monitoring.cfg_schema_contract_column --where table_name like '%doc%'  LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.monitoring.cfg_data_domain

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


SELECT export_date, count(*) FROM LH_BCT_WMPP.silver.referral group by all

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

with may as (
    SELECT 1 mnth, referral_id, count(*) cnt FROM LH_BCT_WMPP.archived.referral WHERE export_date between  '2026-05-01T00:00:00Z' and '2026-05-30T00:00:00Z' group by all
),
jun (
    SELECT 6 mnth, referral_id, count(*) cnt FROM LH_BCT_WMPP.archived.referral WHERE export_date between  '2026-06-01T00:00:00Z' and '2026-06-30T00:00:00Z' group by all
)
,
jul (
    SELECT 7 mnth, referral_id, count(*) cnt FROM LH_BCT_WMPP.archived.referral WHERE export_date between  '2026-07-01T00:00:00Z' and '2026-07-31T00:00:00Z' group by all
)
,
aug (
    SELECT 8 mnth, referral_id, count(*) cnt FROM LH_BCT_WMPP.archived.referral WHERE export_date between  '2026-08-01T00:00:00Z' and '2026-08-31T00:00:00Z' group by all
)
, colla (
select * from may
UNION ALL
select * from jun
UNION ALL
select * from jul
UNION ALL
select * from aug
)
, uni (
select referral_id , MAX(mnth) mn from colla group by all
)
select mn , count(*) from uni group by all

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


--SELECT export_date, count(*) FROM LH_BCT_WMPP.archived.archived_referral group by all
;

SELECT export_date, count(*) FROM LH_BCT_WMPP.archived.referral group by all order by 1 desc
;

SELECT count(distinct referral_id), count(*) FROM LH_BCT_WMPP.archived.referral group by all

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


SELECT count(distinct referral_id), max(export_date) FROM LH_BCT_WMPP.silver.referral group by all

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT snapshot_date, count(*) FROM LH_BCT_WMPP.gold.fact_referral_snapshot 
group by all
limit 10


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.gold.fct_ipa LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT 
*
  FROM monitoring.cfg_data_domain 


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.monitoring.cfg_schema_drift_definition where table_name = 'framework' LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.monitoring.cfg_schema_definition_candidate where table_name = 'framework' LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.monitoring.cfg_schema_contract_column  where table_name = 'framework' LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.monitoring.cfg_archived_schema_live --cfg_bronze_schema_live
where table_name = 'framework'-- and column_name='framework_code'  

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.monitoring.cfg_gold_lineage_mapping

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select * FROM LH_BCT_WMPP.monitoring.cfg_referential_exception 
where detected_at > '2026-08-20T10:13:50Z'

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.monitoring.cfg_schema_drift_event order by detected_at desc LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.monitoring.cfg_silver_load_control order by started_at desc LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.monitoring.cfg_table_load_metric LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT source_schema, source_table, column_name,MAX(distinct_value_count) FROM monitoring.cfg_data_domain group by all


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--delete from monitoring.cfg_silver_export_load

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--delete from monitoring.cfg_month_end_gold_run 

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select * from monitoring.cfg_month_end_gold_run 

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SHOW TABLES IN archived;

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

drop table archived.archived_additional_fee;
drop table archived.archived_foster_carer;
drop table archived.archived_foster_home;
drop table archived.archived_foster_transport;
drop table archived.archived_framework_category;
drop table archived.archived_holding_company;
drop table archived.archived_ipa;
drop table archived.archived_ipa_additional_fee;
drop table archived.archived_ipa_child;
drop table archived.archived_ipa_child_support_needs;
drop table archived.archived_offer;
drop table archived.archived_offer_updates;
drop table archived.archived_offer_view_history;
drop table archived.archived_provider;
drop table archived.archived_provider_education_provision;
drop table archived.archived_provider_framework;
drop table archived.archived_provider_home;
drop table archived.archived_provider_home_age;
drop table archived.archived_provider_home_category;
drop table archived.archived_provider_home_gender;
drop table archived.archived_provider_home_spot_category;
drop table archived.archived_provider_sic_codes;
drop table archived.archived_provider_submission_docs;
drop table archived.archived_referral;
drop table archived.archived_referral_category;
drop table archived.archived_referral_person;
drop table archived.archived_referral_person_support_needs;
drop table archived.archived_referral_provider;
drop table archived.archived_referral_provider_cancel_reason;
drop table archived.archived_referral_provider_decline_reason;
drop table archived.archived_referral_provider_message;
drop table archived.archived_referral_spot_category;
drop table archived.archived_supervising_social_worker;


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


delete  FROM LH_BCT_WMPP.monitoring.cfg_schema_contract_column 
where table_name = 'framework' and column_name ='framework_name'

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--SELECT * FROM LH_BCT_WMPP.archived.cfg_load_control LIMIT 1000

SELECT * FROM LH_BCT_WMPP.monitoring.cfg_schema_contract_column 
where table_name = 'framework' and column_name ='framework_name'

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.gold.dim_date LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.gold.dim_holding_company LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.gold.dim_provider_home LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

-- MAGIC %%pyspark
-- MAGIC 
-- MAGIC spark.sql("SHOW TABLES IN gold").show(truncate=False)

-- METADATA ********************

-- META {
-- META   "language": "python",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT AsOfDate, AVG(estimatedWeeklyCost), SUM(estimatedWeeklyCost), count(distinct referralId) , count(*) , IsPlacementClosed FROM LH_BCT_WMPP.gold.fact_placement
group by all LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.gold.fact_referral_snapshot 
where COALESCE(OfferAcceptedDate,OfferAcceptedDate,FirstOfferDate,OfferAcceptedDate,ReferralClosedDate, FirstProviderSeenDate) is not null 
LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT count(*), AsOfDate FROM LH_BCT_WMPP.gold.fact_referral
group by all  


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT run_id, max(started_at) as started_at, source_table, count(*) 
FROM LH_BCT_WMPP.monitoring.cfg_silver_export_load 
-- where --source_table ='archived.referral' and 
-- run_id ='b3b96fbd-da85-4f58-b8f3-8c0c8134f24e' 
-- order by  started_at desc
group by all
order by  started_at desc


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--RESTORE TABLE LH_BCT_WMPP.monitoring.cfg_schema_drift_event TO VERSION AS OF 233;

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT *
  FROM monitoring.heres a new issue you need to add to the issue log... 
order by started_at desc
limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select * from monitoring.cfg_job_run
order by started_at desc

limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select * from monitoring.cfg_job_step_run
order by started_at desc

limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


select 
* from monitoring.vw_job_run_summary
order by started_at desc
limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select 
* from monitoring.vw_job_step_summary
order by started_at desc
limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select 
* from monitoring.vw_job_step_timing
order by started_at desc
limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select referral_status
,count(*) from bronze.referral a
group by all
limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


select a.referral_status,
bm.*,b.*,o.* from bronze.referral a

inner join bronze.referral_provider b on a.referral_id=b.referral_id
inner join bronze.referral_provider_message bm on bm.referral_provider_id=b.referral_provider_id
left join bronze.offer o on bm.referral_provider_id =o.referral_provider_id
-- where a.referral_id ='8be3f553-130f-4922-b59a-1512371dccec'
--where a.referral_status = 'CLOSED'
limit 100


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************



-- Type a Spark SQL query to get started.
select 
a.referral_status, count(*) 
from bronze.referral a
inner join bronze.referral_provider b on a.referral_id=b.referral_id
left outer join bronze.ipa c on a.referral_id=c.referral_id
--inner join bronze.offer b on a.referral_id =b.refer
-- where a.referral_id ='8be3f553-130f-4922-b59a-1512371dccec'
--where a.referral_status = ''
group by all
limit 100



-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************



-- Type a Spark SQL query to get started.
select  a.referral_id,
a.referral_status, count(*) 
from bronze.referral a
inner join bronze.referral_provider b on a.referral_id=b.referral_id
left outer join bronze.ipa c on a.referral_id=c.referral_id
--inner join bronze.offer b on a.referral_id =b.refer
where a.referral_status = 'CLOSED' 
group by all
limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************



-- Type a Spark SQL query to get started.
select  *
from bronze.referral a
--inner join bronze.referral_provider b on a.referral_id=b.referral_id
left outer join bronze.ipa c on a.referral_id=c.referral_id
--inner join bronze.offer b on a.referral_id =b.refer
where a.referral_status = 'CLOSED' and a.referral_id = '6573d86f-c7f2-4b0d-ba8b-49cce5ce2fdf'
group by all
limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--check offer

select referral_status, count(distinct a.referral_id)
from bronze.referral a
group by all

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select  count(distinct a.referral_id)
from bronze.referral a
left join bronze.referral_provider b on a.referral_id=b.referral_id
left join bronze.offer o on b.referral_provider_id =o.referral_provider_id
anti join bronze.ipa c on a.referral_id=c.referral_id
--inner join bronze.offer b on a.referral_id =b.refer
where o.offer_status ='OFFER_MADE' and referral_status='OPEN'

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--referrals without offers  (231)

-- Type a Spark SQL query to get started.
with cte_offers (select  distinct a.referral_id
from bronze.referral a
left join bronze.referral_provider b on a.referral_id=b.referral_id
left join bronze.offer o on b.referral_provider_id =o.referral_provider_id
anti join bronze.ipa c on a.referral_id=c.referral_id
--inner join bronze.offer b on a.referral_id =b.refer
where o.offer_status ='OFFER_MADE' and referral_status='OPEN'
)
select 
--referral_status, count(distinct a.referral_id)
 *
 from bronze.referral a
left join bronze.referral_provider b on a.referral_id=b.referral_id
left join bronze.offer o on b.referral_provider_id =o.referral_provider_id
anti join bronze.ipa c on a.referral_id=c.referral_id
anti join cte_offers cte on cte.referral_id=a.referral_id
where referral_status='OPEN'
--group by all

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--referrals without offers and no views by providers

-- Type a Spark SQL query to get started.
with cte_offers (select  distinct a.referral_id
from bronze.referral a
left join bronze.referral_provider b on a.referral_id=b.referral_id
left join bronze.offer o on b.referral_provider_id =o.referral_provider_id
--anti join bronze.ipa c on a.referral_id=c.referral_id
--inner join bronze.offer b on a.referral_id =b.refer
where o.offer_status ='OFFER_MADE' and referral_status='OPEN'
),
cte_view_referral (select  distinct a.referral_id
from bronze.referral a
anti join bronze.referral_provider b on a.referral_id=b.referral_id
--inner join bronze.offer b on a.referral_id =b.refer
where referral_status='OPEN'
)
select count(distinct a.referral_id), count(distinct cte_r.referral_id) no_viewed_by_ref
-- *
 from bronze.referral a
left join bronze.referral_provider b on a.referral_id=b.referral_id
left join bronze.offer o on b.referral_provider_id =o.referral_provider_id
anti join bronze.ipa c on a.referral_id=c.referral_id
anti join cte_offers cte on cte.referral_id=a.referral_id
left join cte_view_referral cte_r on cte_r.referral_id=a.referral_id
where referral_status='OPEN'

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--referrals with offers and ipa

-- Type a Spark SQL query to get started.
with cte_offers (select  distinct a.referral_id
from bronze.referral a
left join bronze.referral_provider b on a.referral_id=b.referral_id
left join bronze.offer o on b.referral_provider_id =o.referral_provider_id
--anti join bronze.ipa c on a.referral_id=c.referral_id
--inner join bronze.offer b on a.referral_id =b.refer
where o.offer_status ='OFFER_MADE' 
)
select   a.referral_id, GREATEST(signed_datetime_for_local_authority, signed_datetime_for_provider,   can_sign_date)
-- *
 from bronze.referral a
left join bronze.referral_provider b on a.referral_id=b.referral_id
inner join bronze.offer o on b.referral_provider_id =o.referral_provider_id
left join bronze.provider_home ph on o.provider_home_id =ph.provider_home_id
inner join bronze.ipa c on a.referral_id=c.referral_id
--inner join cte_offers cte on cte.referral_id=a.referral_id
where a.referral_id in 
('855696eb-bca9-44c4-a078-e04d094d76ba'
,'f72847b7-65e2-497a-abcc-90cd359a5c59')
group by all 

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


select  distinct  a.referral_id, signed_datetime_for_local_authority, signed_datetime_for_provider,   can_sign_date
,c.*
 from bronze.referral a
left join bronze.referral_provider b on a.referral_id=b.referral_id
inner join bronze.offer o on b.referral_provider_id =o.referral_provider_id
left join bronze.provider_home ph on o.provider_home_id =ph.provider_home_id
inner join bronze.ipa c on a.referral_id=c.referral_id
where a.referral_id in 
('855696eb-bca9-44c4-a078-e04d094d76ba'
,'f72847b7-65e2-497a-abcc-90cd359a5c59')


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


select  distinct  a.referral_id, c.status, psd.document_name
,  psd.expiry_date , psd.last_updated, psd.next_review_date
 from bronze.referral a
left join bronze.referral_provider b on a.referral_id=b.referral_id
inner join bronze.offer o on b.referral_provider_id =o.referral_provider_id
left join bronze.provider_home ph on o.provider_home_id =ph.provider_home_id
inner join bronze.ipa c on a.referral_id=c.referral_id and c.offer_id=o.offer_id
inner join bronze.provider_submission_docs psd on psd.home_id =o.provider_home_id
where a.referral_id = '5236db3f-cc23-4109-9c0b-eacfb4a277bb'

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select *  
 from bronze.referral a
left join bronze.referral_provider b on a.referral_id=b.referral_id
inner join bronze.offer o on b.referral_provider_id =o.referral_provider_id
inner join bronze.offer_updates oh on oh.offer_id =o.offer_id
where a.referral_id='a6c1fe2d-5e44-44d5-af06-ceb7ac6551aa'
and o.offer_id ='3f10ed89-54c0-401f-adb8-eaf124827054'

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--cross county referrals with offers 

-- Type a Spark SQL query to get started.
with cte_offers (select  distinct a.referral_id
from bronze.referral a
left join bronze.referral_provider b on a.referral_id=b.referral_id
left join bronze.offer o on b.referral_provider_id =o.referral_provider_id
--anti join bronze.ipa c on a.referral_id=c.referral_id
--inner join bronze.offer b on a.referral_id =b.refer
where o.offer_status ='OFFER_MADE' and referral_status='OPEN'
),
cte_view_referral (select  distinct a.referral_id
from bronze.referral a
anti join bronze.referral_provider b on a.referral_id=b.referral_id
--inner join bronze.offer b on a.referral_id =b.refer
where referral_status='OPEN'
)
select a.referral_id,  county
-- *
 from bronze.referral a
left join bronze.referral_provider b on a.referral_id=b.referral_id
inner join bronze.offer o on b.referral_provider_id =o.referral_provider_id
left join bronze.provider_home ph on o.provider_home_id =ph.provider_home_id
anti join bronze.ipa c on a.referral_id=c.referral_id
inner join cte_offers cte on cte.referral_id=a.referral_id
left join cte_view_referral cte_r on cte_r.referral_id=a.referral_id
where referral_status='OPEN'
group by all
order by 2 desc

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--referrals without offers and no views by providers

-- Type a Spark SQL query to get started.
with cte_offers (select  distinct a.referral_id
from bronze.referral a
left join bronze.referral_provider b on a.referral_id=b.referral_id
left join bronze.offer o on b.referral_provider_id =o.referral_provider_id
--anti join bronze.ipa c on a.referral_id=c.referral_id
--inner join bronze.offer b on a.referral_id =b.refer
where o.offer_status ='OFFER_MADE' and referral_status='OPEN'
),
cte_view_referral (select  distinct a.referral_id
from bronze.referral a
anti join bronze.referral_provider b on a.referral_id=b.referral_id
--inner join bronze.offer b on a.referral_id =b.refer
where referral_status='OPEN'
)
select count(distinct a.referral_id), count(distinct cte_r.referral_id) no_viewed_by_ref
-- *
 from bronze.referral a
left join bronze.referral_provider b on a.referral_id=b.referral_id
left join bronze.offer o on b.referral_provider_id =o.referral_provider_id
anti join bronze.ipa c on a.referral_id=c.referral_id
anti join cte_offers cte on cte.referral_id=a.referral_id
left join cte_view_referral cte_r on cte_r.referral_id=a.referral_id
where referral_status='OPEN'

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.silver.supervising_social_worker LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.silver.provider_home_spot_category LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT b.*, a.* FROM LH_BCT_WMPP.silver.referral_category a 
inner join  LH_BCT_WMPP.silver.framework_category b on a.framework_category_id=b.framework_category_id
LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.monitoring.cfg_schema_contract_column where table_name like '%docs%'

--SELECT * FROM LH_BCT_WMPP.monitoring.cfg_schema_definition_candidate where table_name like '%docs%'

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


-- Type a Spark SQL query to get started.
select  o.offer_status, count(*) --,date_diff(NOW(), a.referral_created_date)
from bronze.referral a
left join bronze.referral_provider b on a.referral_id=b.referral_id
left join bronze.offer o on b.referral_provider_id =o.referral_provider_id
--anti join bronze.ipa c on a.referral_id=c.referral_id
--inner join bronze.offer b on a.referral_id =b.refer
--where c.status is not null
group by all
limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************



-- Type a Spark SQL query to get started.
select  referral_status,o.offer_status, count(*) --,date_diff(NOW(), a.referral_created_date)
from bronze.referral a
left join bronze.referral_provider b on a.referral_id=b.referral_id
left join bronze.offer o on b.referral_provider_id =o.referral_provider_id
anti join bronze.ipa c on a.referral_id=c.referral_id
--inner join bronze.offer b on a.referral_id =b.refer
--where c.status is not null
group by all
limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************



-- Type a Spark SQL query to get started.
select  a.referral_id, referral_status, c.status, count(*) ,date_diff(NOW(), a.referral_created_date)
from bronze.referral a
--inner join bronze.referral_provider b on a.referral_id=b.referral_id
inner join bronze.ipa c on a.referral_id=c.referral_id
--inner join bronze.offer b on a.referral_id =b.refer
--where c.status is not null
group by all
limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- MARKDOWN ********************


-- CELL ********************



-- Type a Spark SQL query to get started.
select  
referral_status, c.offer_status, count(*) , count(distinct(a.referral_id))
from bronze.referral a
LEFT join bronze.referral_provider b on a.referral_id=b.referral_id
LEFT join bronze.offer c on c.referral_provider_id=b.referral_provider_id
--inner join bronze.offer b on a.referral_id =b.refer
--where c.offer_status is not null
group by all
limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--check single offer where offer successfull


-- Type a Spark SQL query to get started.
select  a.referral_Id,
referral_status, c.offer_status, count(*), count(distinct c.offer_status), SUM(case when c.offer_status ='OFFER_SUCCESSFUL' THEN 1 ELSE 0 END) dupeSucessOffers
from bronze.referral a
inner join bronze.referral_provider b on a.referral_id=b.referral_id
inner join bronze.offer c on c.referral_provider_id=b.referral_provider_id
--inner join bronze.offer b on a.referral_id =b.refer
where c.offer_status LIKE 'OFFER%'
group by all
limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


-- Type a Spark SQL query to get started.
select  b.referral_provider_id,
--c.referral_provider_id, referral_status, c.offer_status,a.referral_created_date,b.created_date, c.offer_date, 
*
from bronze.referral a
inner join bronze.referral_provider b on a.referral_id=b.referral_id
left join bronze.offer c on c.referral_provider_id=b.referral_provider_id
--inner join bronze.offer b on a.referral_id =b.refer
where a.referral_Id ='cad1b84e-00f9-4788-a361-59dbdd925c6a'
--'cfa96686-ebec-4283-85ba-153a869a41ad'
--'822fdd74-f30e-44f0-aa25-70429d490b5e'
--'822fdd74-f30e-44f0-aa25-70429d490b5e'
--'822fdd74-f30e-44f0-aa25-70429d490b5e'
--'537601ee-ec03-4254-aaaf-687d913c8225'
--'ba5ef268-b1bb-4ed5-b8a3-402f0391976f'
--'f72847b7-65e2-497a-abcc-90cd359a5c59'
--'dad32514-d5d7-49c4-b148-933cce9f40ee' 
-- '4caaaba6-9db8-4fba-ae77-33a568de27bf'

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select 
b.referral_id , b.referral_provider_id, count(*)
from 
bronze.referral_provider b
left join bronze.offer c on c.referral_provider_id=b.referral_provider_id
--where b.referral_Id ='cfa96686-ebec-4283-85ba-153a869a41ad'

--dupe record_id = cad1b84e-00f9-4788-a361-59dbdd925c6a
group by all
having count(*)>1



-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


-- Type a Spark SQL query to get started.
select  b.referral_provider_id, d.provider_id, b.provider_id,
--c.referral_provider_id, referral_status, c.offer_status,a.referral_created_date,b.created_date, c.offer_date, 
*
from bronze.referral a
inner join bronze.referral_provider b on a.referral_id=b.referral_id
left join bronze.offer c on c.referral_provider_id=b.referral_provider_id
left join bronze.provider_home d on c.provider_home_id=d.provider_home_id
where d.provider_id = b.provider_id

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select * 
from 
bronze.referral_provider b
--left join bronze.offer c on c.referral_provider_id=b.referral_provider_id
where b.referral_provider_id= '609ac2f3-8e8e-4053-89c6-7e4bd0ffb129'

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--check single offer where offer successfull


-- Type a Spark SQL query to get started.
select  
referral_status, c.offer_status,a.referral_created_date,b.created_date, c.offer_date, *
from bronze.referral a
inner join bronze.referral_provider b on a.referral_id=b.referral_id
inner join bronze.offer c on c.referral_provider_id=b.referral_provider_id
--inner join bronze.offer b on a.referral_id =b.refer
where c.offer_status ='OFFER_SUCCESSFUL'
group by all
limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************



-- Type a Spark SQL query to get started.
select  --a.referral_id, 
referral_status
--, c.offer_status
, count(*) 
--, date_diff(NOW(), a.referral_created_date)
from bronze.referral a
--inner join bronze.referral_provider b on a.referral_id=b.referral_id
--inner join bronze.offer c on c.referral_provider_id=b.referral_provider_id
--inner join bronze.offer b on a.referral_id =b.refer
--where c.offer_status is not null
group by all
limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.gold.fact_referral_lifecycle_event LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.silver.slv_referral_lifecycle_event LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--SELECT count(*), count(distinct ipa_child_id), count(distinct ipa_id) FROM LH_BCT_WMPP.bronze.ipa_child LIMIT 1000

--SELECT export_date, count(*), count(distinct ipa_child_id), count(distinct ipa_id) FROM LH_BCT_WMPP.bronze.ipa_child group by export_date LIMIT 1000

SELECT  count(*), count(distinct ipa_child_id), count(distinct ipa_id) 
FROM LH_BCT_WMPP.archived.archived_ipa_child LIMIT 1000

--SELECT export_date, count(*), count(distinct ipa_child_id), count(distinct ipa_id)  FROM LH_BCT_WMPP.archived.archived_ipa_child group by export_date LIMIT 1000

--SELECT count(*), count(distinct ipa_child_id), count(distinct ipa_id) FROM LH_BCT_WMPP.silver.slv_ipa_child LIMIT 1000

--SELECT * FROM LH_BCT_WMPP.silver.slv_ipa_child LIMIT 1000



-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.bronze.provider_submission_docs LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.monitoring.cfg_bronze_schema_live where table_name like '%provider_submission_docs%' LIMIT 1000
--SELECT * FROM LH_BCT_WMPP.monitoring.cfg_archived_schema_live where table_name like '%provider_submission_docs%' LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.monitoring.cfg_schema_contract_column where table_name like '%doc%' LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT export_date , count(*) 
FROM LH_BCT_WMPP.silver.slv_referral 
group by export_date
LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT export_date , count(*) 
FROM LH_BCT_WMPP.bronze.referral 
group by export_date
LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

with cte as
(
    SELECT max(export_date) max_export , referral_id
FROM LH_BCT_WMPP.archived.archived_referral 
group by referral_id 
)
select max_export,count(*) from cte group by max_export

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT export_date , count(*) 
FROM LH_BCT_WMPP.archived.archived_referral 
group by export_date
LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.monitoring.cfg_schema_contract_column where table_name ='referral' LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


WITH referral_history AS (
  SELECT *, ROW_NUMBER() OVER (
    PARTITION BY referral_id
    ORDER BY COALESCE(referral_modified_date, referral_created_date, export_date) DESC,
             export_date DESC
  ) AS row_number_current
  FROM silver.slv_referral
),
referral_current AS (
  SELECT * FROM referral_history WHERE row_number_current = 1
),
referral_created AS (
  SELECT referral_id, MIN(referral_created_date) AS ReferralCreatedDate
  FROM silver.slv_referral GROUP BY referral_id
),
offer_rollup AS (
  SELECT rp.referral_id,
    MIN(o.offer_date) AS FirstOfferDate,
    MIN(CASE WHEN LOWER(o.offer_status) IN ('accepted','approved','selected')
        THEN o.last_modified_date END) AS OfferAcceptedDate,
    COUNT(DISTINCT o.offer_id) AS OfferCount,
    COUNT(DISTINCT o.provider_home_id) AS UniqueHomesOffered,
    MAX(COALESCE(o.last_modified_date, o.offer_date)) AS LastOfferActivityDate
  FROM silver.slv_offer o
  INNER JOIN silver.slv_referral_provider rp
    ON o.referral_provider_id = rp.referral_provider_id
  GROUP BY rp.referral_id
),
ipa_rollup AS (
  SELECT referral_id, MIN(created_datetime) AS IPAIssuedDate,
    MIN(placement_admission_date) AS PlannedPlacementStartDate,
    SUM(costs_total_weekly_fee) AS EstimatedWeeklyCost,
    MAX(COALESCE(updated_datetime, created_datetime)) AS LastIPAActivityDate
  FROM silver.slv_ipa GROUP BY referral_id
),
event_rollup AS (
  SELECT referral_id, MIN(event_timestamp) AS FirstActionDate,
    MAX(COALESCE(event_timestamp, created_timestamp)) AS LastEventActivityDate
  FROM silver.slv_referral_event_log GROUP BY referral_id
),
base AS (
  SELECT r.referral_id AS ReferralID, c.ReferralCreatedDate,
    r.required_start_date AS RequiredPlacementDate,
    r.response_required_by_date AS ResponseRequiredDate,
    r.referral_modified_date AS ReferralModifiedTimestamp,
    r.referral_status AS CurrentStatus, r.placement_type AS PlacementTypeRequired,
    e.FirstActionDate, o.FirstOfferDate, o.OfferAcceptedDate, i.IPAIssuedDate,
    CASE WHEN LOWER(COALESCE(r.referral_status, '')) IN ('closed','cancelled','withdrawn','completed')
      THEN COALESCE(r.referral_modified_date, r.export_date) END AS ReferralClosedDate,
    CAST(NULL AS STRING) AS ReferralClosureReason,
    GREATEST(COALESCE(r.referral_modified_date, r.referral_created_date, r.export_date),
      e.LastEventActivityDate, o.LastOfferActivityDate, i.LastIPAActivityDate) AS LastActivityDate,
    o.OfferCount, o.UniqueHomesOffered,
    i.PlannedPlacementStartDate, i.EstimatedWeeklyCost,
    CASE
      WHEN r.required_start_date IS NULL THEN 'Unspecified'
      WHEN DATEDIFF(r.required_start_date, TO_DATE(c.ReferralCreatedDate)) <= 1 THEN 'Critical'
      WHEN DATEDIFF(r.required_start_date, TO_DATE(c.ReferralCreatedDate)) <= 3 THEN 'High'
      WHEN DATEDIFF(r.required_start_date, TO_DATE(c.ReferralCreatedDate)) <= 7 THEN 'Medium'
      ELSE 'Planned'
    END AS PlacementUrgencyBand
  FROM referral_current r
  INNER JOIN referral_created c ON r.referral_id = c.referral_id
  LEFT JOIN offer_rollup o ON r.referral_id = o.referral_id
  LEFT JOIN ipa_rollup i ON r.referral_id = i.referral_id
  LEFT JOIN event_rollup e ON r.referral_id = e.referral_id
)
SELECT '2026-05-30' AS AsOfDate,
  ReferralID, ReferralCreatedDate, RequiredPlacementDate, ResponseRequiredDate,
  FirstActionDate, FirstOfferDate, OfferAcceptedDate, IPAIssuedDate,
  ReferralClosedDate, ReferralClosureReason, LastActivityDate, CurrentStatus,
  PlacementTypeRequired, PlacementUrgencyBand,
  CAST(NULL AS STRING) AS ChildCriticalityCode,
  COALESCE(OfferCount, 0) AS OfferCount,
  COALESCE(UniqueHomesOffered, 0) AS UniqueHomesOffered,
  COALESCE(OfferCount, 0) > 0 AS HasOffer,
  DATEDIFF(TO_DATE(FirstActionDate), TO_DATE(ReferralCreatedDate)) AS DaysToFirstAction,
  DATEDIFF(TO_DATE(FirstOfferDate), TO_DATE(ReferralCreatedDate)) AS DaysToFirstOffer,
  DATEDIFF(TO_DATE(OfferAcceptedDate), TO_DATE(ReferralCreatedDate)) AS DaysToAcceptedOffer,
  DATEDIFF(TO_DATE(IPAIssuedDate), TO_DATE(ReferralCreatedDate)) AS DaysToIPA,
  DATEDIFF(COALESCE(TO_DATE(ReferralClosedDate), '2026-05-30'),
    TO_DATE(ReferralCreatedDate)) AS DaysOpen,
  DATEDIFF('2026-05-30', TO_DATE(LastActivityDate)) AS DaysWithoutActivity,
  CASE WHEN RequiredPlacementDate IS NOT NULL AND RequiredPlacementDate < '2026-05-30'
    THEN DATEDIFF('2026-05-30', RequiredPlacementDate) ELSE 0 END AS DaysPastRequiredDate,
  LOWER(COALESCE(CurrentStatus, '')) NOT IN
    ('closed','cancelled','withdrawn','completed') AS IsOpen,
  IPAIssuedDate IS NOT NULL AND RequiredPlacementDate IS NOT NULL
    AND TO_DATE(IPAIssuedDate) <= RequiredPlacementDate AS PlacedByRequiredDate,
  CASE
    WHEN IPAIssuedDate IS NOT NULL AND RequiredPlacementDate IS NOT NULL
      AND TO_DATE(IPAIssuedDate) <= RequiredPlacementDate THEN 'Placed by target'
    WHEN IPAIssuedDate IS NOT NULL THEN 'Placed after target'
    WHEN RequiredPlacementDate < '2026-05-30' AND LOWER(COALESCE(CurrentStatus, '')) NOT IN
      ('closed','cancelled','withdrawn','completed') THEN 'Open overdue'
    WHEN LOWER(COALESCE(CurrentStatus, '')) NOT IN
      ('closed','cancelled','withdrawn','completed') THEN 'Open on track'
    ELSE 'Closed without placement'
  END AS RequiredPlacementDateOutcome,
  PlannedPlacementStartDate, EstimatedWeeklyCost,
  CURRENT_TIMESTAMP() AS GoldModelledAt
FROM base
WHERE TO_DATE(ReferralCreatedDate) <= '2026-05-30'


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.silver.slv_referral_event_log LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.monitoring.cfg_schema_drift_definition

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

update LH_BCT_WMPP.archived.provider_submission_docs 
set last_updated='2025-11-07'
where last_updated='1025-11-07'

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

-- MAGIC %%pyspark
-- MAGIC 
-- MAGIC from pyspark.sql.types import DateType, TimestampType
-- MAGIC from pyspark.sql.functions import col
-- MAGIC df = spark.table("LH_BCT_WMPP.archived.provider_submission_docs")
-- MAGIC 
-- MAGIC df.printSchema()
-- MAGIC 
-- MAGIC df.describe()
-- MAGIC for field in df.schema.fields:
-- MAGIC     if isinstance(field.dataType, DateType):
-- MAGIC         count = df.filter(col(field.name) < "1582-10-15").count()
-- MAGIC         if count > 0:
-- MAGIC             print(f"{field.name}: {count}")
-- MAGIC 
-- MAGIC     elif isinstance(field.dataType, TimestampType):
-- MAGIC         count = df.filter(col(field.name) < "1900-01-01").count()
-- MAGIC         if count > 0:
-- MAGIC             print(f"{field.name}: {count}")

-- METADATA ********************

-- META {
-- META   "language": "python",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

update  LH_BCT_WMPP.monitoring.cfg_table_load_metric
set source_object = replace(source_object,'archived.archived_','archived.')
where source_object like "%.archived_%"
;


update  LH_BCT_WMPP.monitoring.cfg_table_load_metric
set target_object = replace(target_object,'silver.slv_','silver.')
where target_object like "silver.slv_%"

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.silver.provider_submission_docs LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.silver.provider_submission_docs LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

update  LH_BCT_WMPP.monitoring.cfg_silver_export_load
set source_table = replace(source_table,'archived.archived_','archived.')
where source_table like "%.archived_%"

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT * FROM LH_BCT_WMPP.silver.framework LIMIT 1000

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

-- MAGIC %%pyspark
-- MAGIC 
-- MAGIC from pyspark.sql.functions import min
-- MAGIC from pyspark.sql.functions import col
-- MAGIC 
-- MAGIC date_cols = [
-- MAGIC     "expiry_date",
-- MAGIC     "last_updated",
-- MAGIC     "next_review_date",
-- MAGIC     "start_date"
-- MAGIC ]
-- MAGIC 
-- MAGIC 
-- MAGIC for c in date_cols:
-- MAGIC     print(f"col: {c}")
-- MAGIC     df.select(min(c).alias("min_date")).show()

-- METADATA ********************

-- META {
-- META   "language": "python",
-- META   "language_group": "synapse_pyspark"
-- META }
