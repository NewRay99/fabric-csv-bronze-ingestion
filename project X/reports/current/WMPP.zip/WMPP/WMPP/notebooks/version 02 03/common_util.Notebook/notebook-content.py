# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "d286fa39-f255-4ba7-a982-32cb69362ef7",
# META       "default_lakehouse_name": "LH_BCT_WMPP",
# META       "default_lakehouse_workspace_id": "fefdb483-d26c-4bd9-9a4f-0c41cc786770",
# META       "known_lakehouses": [
# META         {
# META           "id": "d286fa39-f255-4ba7-a982-32cb69362ef7"
# META         }
# META       ]
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Common ETL exclusions
# 
# Shared table exclusions for ingestion, schema capture, and Silver formatting.
# Internal/reference tables do not represent dated source extracts and must not be required to carry `export_date`.


# CELL ********************

ETL_EXCLUDED_TABLES = [
    "ref_KPI_Definition",
    "ref_KPI_RID_linkage",
    "ref_RID",
    "ref_Table_Lineage",
]
ETL_EXCLUDED_TABLE_PREFIXES = ["ref_"]
ETL_PHYSICAL_PREFIXES = ("brz_", "archived_", "slv_")


def etl_logical_table_name(table_name):
    name = str(table_name or "").replace("\\", "/").rsplit("/", 1)[-1]
    name = name.rsplit(".", 1)[0] if name.lower().endswith((".csv", ".parquet")) else name
    name = name.rsplit(".", 1)[-1].lower()
    for prefix in ETL_PHYSICAL_PREFIXES:
        if name.startswith(prefix):
            name = name[len(prefix):]
    return name


_ETL_EXCLUDED_TABLES_LOWER = {name.lower() for name in ETL_EXCLUDED_TABLES}
_ETL_EXCLUDED_PREFIXES_LOWER = tuple(prefix.lower() for prefix in ETL_EXCLUDED_TABLE_PREFIXES)


def is_etl_excluded_table(table_name):
    logical_name = etl_logical_table_name(table_name)
    return (
        logical_name in _ETL_EXCLUDED_TABLES_LOWER
        or logical_name.startswith(_ETL_EXCLUDED_PREFIXES_LOWER)
    )


def excluded_etl_tables(table_names):
    return sorted(name for name in table_names if is_etl_excluded_table(name))


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
