"""Fast static regressions for the Version 02 03 Fabric notebook fixes."""

import ast
from notebook_loader import load_notebook as read_notebook
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
NOTEBOOKS = [
    "00_archive_load.py",
    "00_setup_cfg.py",
    "00a_rehydrate_archive_cfg.py",
    "00b_reset_silver_cfg.py",
    "01_bronze_get_latest.py",
    "99_common_library.py",
    "02_silver_formatter.py",
    "02a_archive_silver.py",
    "05_gold_dimensions.py",
    "06_reports.py",
]


def load_notebook(name):
    notebook = read_notebook(ROOT / name)
    assert notebook["nbformat"] == 4
    for index, cell in enumerate(notebook["cells"]):
        source = "".join(cell.get("source", []))
        if cell["cell_type"] == "code" and not source.lstrip().startswith("%"):
            ast.parse(source, filename=f"{name}:cell-{index}")
    return notebook


def source(notebook):
    return "\n".join("".join(cell.get("source", [])) for cell in notebook["cells"])


notebooks = {name: load_notebook(name) for name in NOTEBOOKS}
print("PASS Fabric notebook cells and Python syntax")

formatter_run_cells = [
    "".join(cell.get("source", []))
    for cell in notebooks["02_silver_formatter.py"]["cells"]
    if "".join(cell.get("source", [])).lstrip().startswith("%run ./99_common_library")
]
assert formatter_run_cells == ["%run ./99_common_library\n"], (
    "02_silver_formatter: Fabric %run must be the only command in its cell"
)
issue_log = (ROOT / "99_Change_Tracking" / "ETL_ISSUE_LOG.md").read_text(
    encoding="utf-8"
)
assert "## SI-024" in issue_log
assert "## SL-N+1" not in issue_log
print("PASS formatter common-library %run is isolated in its own magic cell")

for name in ["00_setup_cfg.py", "99_common_library.py"]:
    text = source(notebooks[name])
    assignment = text.find("TIME_PARSER_POLICY =")
    use = text.find('spark.conf.set("spark.sql.legacy.timeParserPolicy", TIME_PARSER_POLICY)')
    assert assignment >= 0 and assignment < use, (
        f"{name}: TIME_PARSER_POLICY must have a local default before use"
    )
print("PASS shared/setup parser policy is self-contained")

CFG_CALLERS = [
    "00a_rehydrate_archive_cfg.py",
    "00b_reset_silver_cfg.py",
    "02a_archive_silver.py",
]
for name in CFG_CALLERS:
    text = source(notebooks[name])
    assert '"AUDIT_TABLE": AUDIT_TABLE' in text, (
        f"{name}: child-notebook parameter must pass the variable value"
    )
    assert '{"AUDIT_TABLE": "{AUDIT_TABLE}"}' not in text
    assert '"AUDIT_TABLE": ""' not in text
    assert "from notebookutils import mssparkutils" in text
print("PASS cfg notebook receives the resolved audit-table name")

RUNNER_CHILD_CFG_CALLERS = [
    "00_archive_load.py",
    "01_bronze_get_latest.py",
    "01a_cfg_schema_capture_archive.py",
    "02a_archive_silver.py",
]
for name in RUNNER_CHILD_CFG_CALLERS:
    text = source(load_notebook(name))
    assert "IS_ORCHESTRATED_RUN = bool(JOB_RUN_ID)" in text, (
        f"{name}: must detect a parent JOB_RUN_ID before local state is created"
    )
    assert "if not IS_ORCHESTRATED_RUN:" in text, (
        f"{name}: must run configuration setup only for a standalone run"
    )
    assert "SKIP configuration setup: parent runner completed 00_setup_cfg" in text
print("PASS runner children do not repeat parent configuration setup")

reset_text = source(notebooks["00b_reset_silver_cfg.py"])
assert reset_text.find("def qident") < reset_text.find("cfg_result ="), (
    "00b reset must define qident before the cfg setup cell uses it"
)
print("PASS reset helper execution order")

for name in ["02_silver_formatter.py", "02a_archive_silver.py"]:
    text = source(notebooks[name])
    assert "SKIPPED_NO_CONTRACT" in text, (
        f"{name}: missing contracts must be auditable non-fatal skips"
    )
    assert "MISSING_TABLE_CONTRACT" in text
    assert "monitoring.cfg_schema_drift_event" in text
print("PASS missing table contracts are logged and skipped")
