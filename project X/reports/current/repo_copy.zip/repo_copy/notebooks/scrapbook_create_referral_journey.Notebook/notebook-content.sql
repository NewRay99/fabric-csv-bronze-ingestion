-- Fabric notebook source

-- METADATA ********************

-- META {
-- META   "kernel_info": {
-- META     "name": "synapse_pyspark"
-- META   },
-- META   "dependencies": {
-- META     "lakehouse": {
-- META       "default_lakehouse": "d286fa39-f255-4ba7-a982-32cb69362ef7",
-- META       "default_lakehouse_name": "LH_BCT_WMPP",
-- META       "default_lakehouse_workspace_id": "fefdb483-d26c-4bd9-9a4f-0c41cc786770",
-- META       "known_lakehouses": [
-- META         {
-- META           "id": "d286fa39-f255-4ba7-a982-32cb69362ef7"
-- META         }
-- META       ]
-- META     }
-- META   }
-- META }

-- CELL ********************

-- BCT WMPP referral journey flow for Power BI Sankey
-- Grain: one referral x one canonical source-to-target transition.
-- Weight: referral_count = 1. Power BI should SUM(referral_count).
--
-- This is a current-state journey derived from the current Gold facts.
-- It intentionally collapses multiple provider assignments/offers/IPAs to a
-- single referral path so Sankey branch totals conserve referral counts.

CREATE OR REPLACE MATERIALIZED LAKE VIEW gold.referral_journey_flow
(
    CONSTRAINT valid_referral_id
        CHECK (referral_id IS NOT NULL) ON MISMATCH FAIL,
    CONSTRAINT valid_stage_order
        CHECK (source_stage_order < target_stage_order) ON MISMATCH FAIL,
    CONSTRAINT unit_referral_weight
        CHECK (referral_count = 1) ON MISMATCH FAIL
)
COMMENT "Referral-level canonical journey transitions for Power BI Sankey reporting"
AS
WITH provider_rollup AS (
    SELECT
        referral_id,
        COUNT(*) AS provider_assignment_rows,
        SUM(CASE WHEN COALESCE(is_cancelled, FALSE) THEN 1 ELSE 0 END)
            AS provider_cancelled_rows,
        SUM(CASE WHEN COALESCE(is_declined, FALSE) THEN 1 ELSE 0 END)
            AS provider_declined_rows,
        SUM(CASE WHEN COALESCE(is_closed, FALSE) THEN 1 ELSE 0 END)
            AS provider_closed_rows,
        SUM(CASE WHEN COALESCE(is_excluded, FALSE) THEN 1 ELSE 0 END)
            AS provider_excluded_rows,
        SUM(CASE WHEN COALESCE(is_engaged, FALSE) THEN 1 ELSE 0 END)
            AS provider_engaged_rows
    FROM gold.fact_referral_provider
    GROUP BY referral_id
),
offer_rollup AS (
    SELECT
        referral_id,
        COUNT(*) AS offer_rows,
        SUM(CASE
            WHEN offer_submitted_date IS NOT NULL THEN 1 ELSE 0
        END) AS submitted_offer_rows,
        -- Treat OfferUpdated as genuine progress only when the modification
        -- timestamp is later than submission. The current lifecycle roll-up
        -- otherwise emits OfferUpdated whenever last_modified_date is present.
        SUM(CASE
            WHEN offer_reviewed_date IS NOT NULL
             AND offer_submitted_date IS NOT NULL
             AND offer_reviewed_date > offer_submitted_date
            THEN 1 ELSE 0
        END) AS updated_offer_rows,
        SUM(CASE
            WHEN LOWER(COALESCE(offer_status, '')) IN
                 ('accepted', 'approved', 'selected', 'offer_successful')
            THEN 1 ELSE 0
        END) AS accepted_offer_rows,
        SUM(CASE
            WHEN LOWER(COALESCE(offer_status, '')) IN
                 ('declined', 'rejected', 'offer_unsuccessful')
            THEN 1 ELSE 0
        END) AS unsuccessful_offer_rows,
        SUM(CASE
            WHEN LOWER(COALESCE(offer_status, '')) IN
                 ('withdrawn', 'offer_withdrawn')
            THEN 1 ELSE 0
        END) AS withdrawn_offer_rows,
        SUM(CASE
            WHEN LOWER(COALESCE(offer_status, '')) NOT IN
                 ('accepted', 'approved', 'selected', 'offer_successful',
                  'declined', 'rejected', 'offer_unsuccessful',
                  'withdrawn', 'offer_withdrawn')
            THEN 1 ELSE 0
        END) AS active_or_other_offer_rows
    FROM gold.fact_offer
    GROUP BY referral_id
),
ipa_rollup AS (
    SELECT
        referral_id,
        COUNT(*) AS ipa_rows,
        SUM(CASE WHEN ipa_issued_date IS NOT NULL THEN 1 ELSE 0 END)
            AS issued_ipa_rows,
        SUM(CASE WHEN placement_admission_date IS NOT NULL THEN 1 ELSE 0 END)
            AS admission_rows,
        SUM(CASE WHEN COALESCE(is_placement_closed, FALSE) THEN 1 ELSE 0 END)
            AS closed_ipa_rows,
        SUM(CASE WHEN NOT COALESCE(is_placement_closed, FALSE) THEN 1 ELSE 0 END)
            AS open_ipa_rows
    FROM gold.fact_ipa
    GROUP BY referral_id
),
referral_state AS (
    SELECT
        r.as_of_date,
        r.referral_id,
        r.referral_created_date,
        r.placement_type_required,
        r.priority,
        r.is_spot,
        r.current_status,

        LOWER(COALESCE(r.current_status, '')) = 'cancelled'
            AS referral_cancelled,
        LOWER(COALESCE(r.current_status, '')) IN
            ('closed', 'withdrawn', 'completed')
            AS referral_closed_other,

        COALESCE(p.provider_assignment_rows, 0) AS provider_assignment_rows,
        COALESCE(p.provider_cancelled_rows, 0) AS provider_cancelled_rows,
        COALESCE(p.provider_declined_rows, 0) AS provider_declined_rows,
        COALESCE(p.provider_closed_rows, 0) AS provider_closed_rows,
        COALESCE(p.provider_excluded_rows, 0) AS provider_excluded_rows,
        COALESCE(p.provider_engaged_rows, 0) AS provider_engaged_rows,

        COALESCE(o.offer_rows, 0) AS offer_rows,
        COALESCE(o.submitted_offer_rows, 0) AS submitted_offer_rows,
        COALESCE(o.updated_offer_rows, 0) AS updated_offer_rows,
        COALESCE(o.accepted_offer_rows, 0) AS accepted_offer_rows,
        COALESCE(o.unsuccessful_offer_rows, 0) AS unsuccessful_offer_rows,
        COALESCE(o.withdrawn_offer_rows, 0) AS withdrawn_offer_rows,
        COALESCE(o.active_or_other_offer_rows, 0) AS active_or_other_offer_rows,

        COALESCE(i.ipa_rows, 0) AS ipa_rows,
        COALESCE(i.issued_ipa_rows, 0) AS issued_ipa_rows,
        COALESCE(i.admission_rows, 0) AS admission_rows,
        COALESCE(i.closed_ipa_rows, 0) AS closed_ipa_rows,
        COALESCE(i.open_ipa_rows, 0) AS open_ipa_rows,

        -- Use referral-grain Gold enrichment as a second evidence path so a
        -- referral is not lost merely because a child fact is absent from the
        -- current filtered Gold slice.
        (
            COALESCE(p.provider_assignment_rows, 0) > 0
            OR COALESCE(r.provider_assignment_count, 0) > 0
            OR COALESCE(o.offer_rows, 0) > 0
            OR COALESCE(r.offer_count, 0) > 0
            OR COALESCE(i.ipa_rows, 0) > 0
            OR r.ipa_issued_date IS NOT NULL
        ) AS has_provider_stage,

        (
            COALESCE(o.submitted_offer_rows, 0) > 0
            OR COALESCE(r.offer_count, 0) > 0
            OR COALESCE(r.has_offer, FALSE)
        ) AS has_offer_submitted,

        COALESCE(o.updated_offer_rows, 0) > 0 AS has_offer_updated,

        (
            COALESCE(o.accepted_offer_rows, 0) > 0
            OR r.offer_accepted_date IS NOT NULL
        ) AS has_offer_accepted,

        (
            COALESCE(i.issued_ipa_rows, 0) > 0
            OR COALESCE(i.ipa_rows, 0) > 0
            OR r.ipa_issued_date IS NOT NULL
        ) AS has_ipa_created,

        (
            COALESCE(i.admission_rows, 0) > 0
            OR r.ipa_placement_admission_date IS NOT NULL
        ) AS has_placement_admission

    FROM gold.fact_referral r
    LEFT JOIN provider_rollup p
        ON r.referral_id = p.referral_id
    LEFT JOIN offer_rollup o
        ON r.referral_id = o.referral_id
    LEFT JOIN ipa_rollup i
        ON r.referral_id = i.referral_id
),
edges AS (
    -- Every referral contributes exactly one outgoing edge from Created.
    SELECT
        s.*,
        'Referral Created' AS source_stage,
        10 AS source_stage_order,
        CASE
            WHEN has_provider_stage THEN 'Provider Referred'
            WHEN referral_cancelled THEN 'Referral Cancelled'
            WHEN referral_closed_other THEN 'Referral Closed / Withdrawn'
            ELSE 'Awaiting Provider'
        END AS target_stage,
        CASE
            WHEN has_provider_stage THEN 20
            WHEN referral_cancelled THEN 200
            WHEN referral_closed_other THEN 201
            ELSE 202
        END AS target_stage_order
    FROM referral_state s

    UNION ALL

    -- Referral-level provider path. Multiple provider assignments collapse to
    -- one canonical referral outcome; an offer always wins over provider-level
    -- cancellation/decline because the referral demonstrably progressed.
    SELECT
        s.*,
        'Provider Referred' AS source_stage,
        20 AS source_stage_order,
        CASE
            WHEN has_offer_submitted THEN 'Offer Submitted'
            WHEN has_ipa_created THEN 'IPA Created'
            WHEN referral_cancelled THEN 'Referral Cancelled'
            WHEN referral_closed_other THEN 'Referral Closed / Withdrawn'
            WHEN provider_assignment_rows > 0
             AND provider_cancelled_rows = provider_assignment_rows
                THEN 'Provider Referral Cancelled'
            WHEN provider_assignment_rows > 0
             AND provider_declined_rows = provider_assignment_rows
                THEN 'Provider Declined'
            WHEN provider_engaged_rows > 0 THEN 'Awaiting Offer'
            ELSE 'Provider Closed / No Offer'
        END AS target_stage,
        CASE
            WHEN has_offer_submitted THEN 30
            WHEN has_ipa_created THEN 60
            WHEN referral_cancelled THEN 200
            WHEN referral_closed_other THEN 201
            WHEN provider_assignment_rows > 0
             AND provider_cancelled_rows = provider_assignment_rows THEN 203
            WHEN provider_assignment_rows > 0
             AND provider_declined_rows = provider_assignment_rows THEN 204
            WHEN provider_engaged_rows > 0 THEN 205
            ELSE 206
        END AS target_stage_order
    FROM referral_state s
    WHERE has_provider_stage

    UNION ALL

    -- Offer submission path. A genuine modification progresses to Offer
    -- Updated. If there is no update evidence, a terminal/current offer state
    -- is used directly.
    SELECT
        s.*,
        'Offer Submitted' AS source_stage,
        30 AS source_stage_order,
        CASE
            WHEN has_offer_updated THEN 'Offer Updated'
            WHEN has_offer_accepted THEN 'Offer Accepted'
            WHEN has_ipa_created THEN 'IPA Created'
            WHEN referral_cancelled THEN 'Referral Cancelled'
            WHEN referral_closed_other THEN 'Referral Closed / Withdrawn'
            WHEN offer_rows > 0 AND withdrawn_offer_rows = offer_rows
                THEN 'Offer Withdrawn'
            WHEN offer_rows > 0 AND unsuccessful_offer_rows = offer_rows
                THEN 'Offer Unsuccessful'
            ELSE 'Awaiting Offer Update'
        END AS target_stage,
        CASE
            WHEN has_offer_updated THEN 40
            WHEN has_offer_accepted THEN 50
            WHEN has_ipa_created THEN 60
            WHEN referral_cancelled THEN 200
            WHEN referral_closed_other THEN 201
            WHEN offer_rows > 0 AND withdrawn_offer_rows = offer_rows THEN 207
            WHEN offer_rows > 0 AND unsuccessful_offer_rows = offer_rows THEN 208
            ELSE 209
        END AS target_stage_order
    FROM referral_state s
    WHERE has_offer_submitted

    UNION ALL

    -- Once an offer has genuinely updated, accepted evidence takes precedence;
    -- otherwise classify the referral by the aggregate state of all offers.
    SELECT
        s.*,
        'Offer Updated' AS source_stage,
        40 AS source_stage_order,
        CASE
            WHEN has_offer_accepted THEN 'Offer Accepted'
            WHEN has_ipa_created THEN 'IPA Created'
            WHEN referral_cancelled THEN 'Referral Cancelled'
            WHEN referral_closed_other THEN 'Referral Closed / Withdrawn'
            WHEN offer_rows > 0 AND withdrawn_offer_rows = offer_rows
                THEN 'Offer Withdrawn'
            WHEN offer_rows > 0 AND unsuccessful_offer_rows = offer_rows
                THEN 'Offer Unsuccessful'
            WHEN active_or_other_offer_rows > 0 THEN 'Offer Pending / Other'
            ELSE 'Offer Closed / No Acceptance'
        END AS target_stage,
        CASE
            WHEN has_offer_accepted THEN 50
            WHEN has_ipa_created THEN 60
            WHEN referral_cancelled THEN 200
            WHEN referral_closed_other THEN 201
            WHEN offer_rows > 0 AND withdrawn_offer_rows = offer_rows THEN 207
            WHEN offer_rows > 0 AND unsuccessful_offer_rows = offer_rows THEN 208
            WHEN active_or_other_offer_rows > 0 THEN 210
            ELSE 211
        END AS target_stage_order
    FROM referral_state s
    WHERE has_offer_updated

    UNION ALL

    SELECT
        s.*,
        'Offer Accepted' AS source_stage,
        50 AS source_stage_order,
        CASE
            WHEN has_ipa_created THEN 'IPA Created'
            WHEN referral_cancelled THEN 'Referral Cancelled'
            WHEN referral_closed_other THEN 'Referral Closed / Withdrawn'
            ELSE 'Awaiting IPA'
        END AS target_stage,
        CASE
            WHEN has_ipa_created THEN 60
            WHEN referral_cancelled THEN 200
            WHEN referral_closed_other THEN 201
            ELSE 212
        END AS target_stage_order
    FROM referral_state s
    WHERE has_offer_accepted

    UNION ALL

    SELECT
        s.*,
        'IPA Created' AS source_stage,
        60 AS source_stage_order,
        CASE
            WHEN has_placement_admission THEN 'Placement Admission'
            WHEN referral_cancelled THEN 'Referral Cancelled'
            WHEN referral_closed_other THEN 'Referral Closed / Withdrawn'
            WHEN ipa_rows > 0 AND closed_ipa_rows = ipa_rows THEN 'IPA Closed'
            ELSE 'Awaiting Placement'
        END AS target_stage,
        CASE
            WHEN has_placement_admission THEN 70
            WHEN referral_cancelled THEN 200
            WHEN referral_closed_other THEN 201
            WHEN ipa_rows > 0 AND closed_ipa_rows = ipa_rows THEN 213
            ELSE 214
        END AS target_stage_order
    FROM referral_state s
    WHERE has_ipa_created

    UNION ALL

    SELECT
        s.*,
        'Placement Admission' AS source_stage,
        70 AS source_stage_order,
        CASE
            WHEN referral_cancelled THEN 'Referral Cancelled'
            WHEN open_ipa_rows > 0 THEN 'Placement Active'
            WHEN ipa_rows > 0 AND closed_ipa_rows = ipa_rows THEN 'Placement Closed'
            WHEN referral_closed_other THEN 'Referral Closed / Withdrawn'
            ELSE 'Placement Active'
        END AS target_stage,
        CASE
            WHEN referral_cancelled THEN 200
            WHEN open_ipa_rows > 0 THEN 215
            WHEN ipa_rows > 0 AND closed_ipa_rows = ipa_rows THEN 216
            WHEN referral_closed_other THEN 201
            ELSE 215
        END AS target_stage_order
    FROM referral_state s
    WHERE has_placement_admission
)
SELECT
    SHA2(
        CONCAT_WS('||', referral_id, source_stage, target_stage),
        256
    ) AS transition_id,
    as_of_date,
    referral_id,
    referral_created_date,
    placement_type_required,
    priority,
    is_spot,
    current_status,
    source_stage,
    source_stage_order,
    target_stage,
    target_stage_order,
    CAST(1 AS BIGINT) AS referral_count,
    target_stage IN (
        'Referral Cancelled',
        'Referral Closed / Withdrawn',
        'Awaiting Provider',
        'Provider Referral Cancelled',
        'Provider Declined',
        'Awaiting Offer',
        'Provider Closed / No Offer',
        'Offer Withdrawn',
        'Offer Unsuccessful',
        'Awaiting Offer Update',
        'Offer Pending / Other',
        'Offer Closed / No Acceptance',
        'Awaiting IPA',
        'IPA Closed',
        'Awaiting Placement',
        'Placement Active',
        'Placement Closed'
    ) AS is_terminal_target
FROM edges;

-- ============================================================================
-- Power BI fields
-- ============================================================================
-- Source      : source_stage
-- Destination : target_stage
-- Weight      : SUM(referral_count)
-- Tooltip     : DISTINCTCOUNT(referral_id) (should equal SUM(referral_count)
--               for any single source/target link)
--
-- Recommended relationship:
--   gold.fact_referral[referral_id] 1 -> * gold.referral_journey_flow[referral_id]
--   single-direction from fact_referral to referral_journey_flow.

-- ============================================================================
-- Reconciliation / acceptance checks
-- ============================================================================

-- 1. Every eligible referral must leave Referral Created exactly once.
SELECT
    (SELECT COUNT(*) FROM gold.fact_referral) AS gold_referrals,
    (SELECT SUM(referral_count)
       FROM gold.referral_journey_flow
      WHERE source_stage = 'Referral Created') AS journey_created_referrals;

-- 2. No referral may have more than one outgoing edge from the same source node.
SELECT referral_id, source_stage, COUNT(*) AS edge_count
FROM gold.referral_journey_flow
GROUP BY referral_id, source_stage
HAVING COUNT(*) > 1;

-- 3. Progression nodes must conserve referral counts: incoming = outgoing.
WITH incoming AS (
    SELECT target_stage AS stage, SUM(referral_count) AS incoming_count
    FROM gold.referral_journey_flow
    GROUP BY target_stage
),
outgoing AS (
    SELECT source_stage AS stage, SUM(referral_count) AS outgoing_count
    FROM gold.referral_journey_flow
    GROUP BY source_stage
)
SELECT
    o.stage,
    COALESCE(i.incoming_count, 0) AS incoming_count,
    o.outgoing_count,
    COALESCE(i.incoming_count, 0) - o.outgoing_count AS difference
FROM outgoing o
LEFT JOIN incoming i ON o.stage = i.stage
WHERE o.stage IN (
    'Provider Referred',
    'Offer Submitted',
    'Offer Updated',
    'Offer Accepted',
    'IPA Created',
    'Placement Admission'
)
ORDER BY o.stage;

-- 4. Summarised Sankey dataset (optional validation / export).
SELECT
    source_stage,
    source_stage_order,
    target_stage,
    target_stage_order,
    SUM(referral_count) AS referral_count
FROM gold.referral_journey_flow
GROUP BY
    source_stage,
    source_stage_order,
    target_stage,
    target_stage_order
ORDER BY source_stage_order, target_stage_order, target_stage;


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT
*
FROM gold.referral_journey_flow

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }
