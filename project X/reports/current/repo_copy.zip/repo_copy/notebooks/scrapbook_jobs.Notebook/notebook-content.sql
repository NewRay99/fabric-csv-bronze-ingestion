-- Fabric notebook source

-- METADATA ********************

-- META {
-- META   "kernel_info": {
-- META     "name": "synapse_pyspark"
-- META   },
-- META   "dependencies": {
-- META     "lakehouse": {
-- META       "default_lakehouse": "d286fa39-f255-4ba7-a982-32cb69362ef7",
-- META       "default_lakehouse_name": "LH_BCT_WMPP",
-- META       "default_lakehouse_workspace_id": "fefdb483-d26c-4bd9-9a4f-0c41cc786770",
-- META       "known_lakehouses": [
-- META         {
-- META           "id": "d286fa39-f255-4ba7-a982-32cb69362ef7"
-- META         }
-- META       ]
-- META     }
-- META   }
-- META }

-- CELL ********************

SELECT *
  FROM monitoring.cfg_pipeline_run
order by started_at desc
limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

SELECT *
  FROM monitoring.cfg_job_step_run
order by started_at desc
limit 100



-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select * from monitoring.cfg_job_run
order by started_at desc

limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


select 
* from monitoring.vw_job_run_summary
order by started_at desc
limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select 
* from monitoring.vw_job_step_timing
order by started_at desc
limit 100

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }
