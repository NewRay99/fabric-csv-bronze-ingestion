-- Fabric notebook source

-- METADATA ********************

-- META {
-- META   "kernel_info": {
-- META     "name": "synapse_pyspark"
-- META   },
-- META   "dependencies": {
-- META     "lakehouse": {
-- META       "default_lakehouse": "d286fa39-f255-4ba7-a982-32cb69362ef7",
-- META       "default_lakehouse_name": "LH_BCT_WMPP",
-- META       "default_lakehouse_workspace_id": "fefdb483-d26c-4bd9-9a4f-0c41cc786770",
-- META       "known_lakehouses": [
-- META         {
-- META           "id": "d286fa39-f255-4ba7-a982-32cb69362ef7"
-- META         }
-- META       ]
-- META     }
-- META   }
-- META }

-- CELL ********************


select * from  silver.framework b 

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************


select * from  silver.framework_category b 


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select o.offer_id,rp.referral_id, ofc.framework_code,c.framework_code, c2.framework_code,p.provider_name, ph.home_name,*
from silver.provider_home_category a
inner join silver.framework_category b on a.framework_category_id = b.framework_category_id
inner join silver.framework c on c.framework_code = b.framework_code 
inner join silver.provider_home ph on ph.provider_home_id = a.provider_home_id
inner join silver.provider p on p.provider_id = ph.provider_id
inner join silver.provider_framework pf on pf.provider_id = ph.provider_id
inner join silver.framework c2 on c2.framework_code = pf.framework_code 
inner join silver.offer o on o.provider_home_id = ph.provider_home_id
inner join  silver.referral_provider rp on o.referral_provider_id=rp.referral_provider_id
inner join silver.framework_category ofc on o.category = ofc.framework_category_id
inner join silver.referral r on r.referral_id = rp.referral_id
where ph.provider_home_id='9c9ed9c9-4537-4a67-9688-5a7d7962a4ce'
and r.referral_id = 'ef9d1a8e-25c1-450f-b6bd-7993fefd60c8'

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--start from provider_home_category
select o.offer_id,rp.referral_id
,rfc.framework_code
, ofc.framework_code,c.framework_code, c2.framework_code,p.provider_name, ph.home_name,*
from silver.provider_home_category a
inner join silver.framework_category b on a.framework_category_id = b.framework_category_id
inner join silver.framework c on c.framework_code = b.framework_code 
inner join silver.provider_home ph on ph.provider_home_id = a.provider_home_id
inner join silver.provider p on p.provider_id = ph.provider_id
inner join silver.provider_framework pf on pf.provider_id = ph.provider_id
inner join silver.framework c2 on c2.framework_code = pf.framework_code 
inner join silver.offer o on o.provider_home_id = ph.provider_home_id
inner join silver.referral_provider rp on o.referral_provider_id=rp.referral_provider_id
inner join silver.framework_category ofc on o.category = ofc.framework_category_id
inner join silver.referral r on r.referral_id = rp.referral_id
inner join silver.referral_category rc on r.referral_id = rc.referral_id
inner join silver.framework_category rfc on rc.framework_category_id = rfc.framework_category_id
where rfc.framework_code<> ofc.framework_code

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select * from silver.provider_framework pf
inner join silver.provider p on pf.provider_id = p.provider_id
inner join silver.framework pffc on pf.framework_code = pffc.framework_code
where p.provider_name = 'A1 Support LTD'


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--written from offer perspective first
--this helps map the fact records and their lineage to the framework_category

--the frameowrk does not always match between referral framework and provider home framework
--similarly the looking at the offer,  the offer framework and provider home framework dont always match


select o.offer_id,rp.referral_id
, rfc.framework_code r_fw_code
, ofc.framework_code o_fw_code
, phcfc.framework_code ph_fw_code
-- , c2.framework_code
, p.provider_name
, ph.home_name
, phcfc.*
from silver.offer o
inner join silver.referral_provider rp on o.referral_provider_id=rp.referral_provider_id
inner join silver.framework_category ofc on o.category = ofc.framework_category_id
inner join silver.referral r on r.referral_id = rp.referral_id
inner join silver.referral_category rc on r.referral_id = rc.referral_id
inner join silver.framework_category rfc on rc.framework_category_id = rfc.framework_category_id
inner join silver.provider_home_category phc on o.provider_home_id = phc.provider_home_id
inner join silver.framework_category phcfc on phcfc.framework_category_id = phc.framework_category_id
inner join silver.provider_home ph on ph.provider_home_id = o.provider_home_id
inner join silver.provider p on p.provider_id = ph.provider_id
where phcfc.framework_code<> ofc.framework_code
or phcfc.framework_code<> rfc.framework_code

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }
