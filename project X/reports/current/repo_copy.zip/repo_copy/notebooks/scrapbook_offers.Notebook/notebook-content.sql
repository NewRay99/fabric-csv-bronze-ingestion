-- Fabric notebook source

-- METADATA ********************

-- META {
-- META   "kernel_info": {
-- META     "name": "synapse_pyspark"
-- META   },
-- META   "dependencies": {
-- META     "lakehouse": {
-- META       "default_lakehouse": "d286fa39-f255-4ba7-a982-32cb69362ef7",
-- META       "default_lakehouse_name": "LH_BCT_WMPP",
-- META       "default_lakehouse_workspace_id": "fefdb483-d26c-4bd9-9a4f-0c41cc786770",
-- META       "known_lakehouses": [
-- META         {
-- META           "id": "d286fa39-f255-4ba7-a982-32cb69362ef7"
-- META         }
-- META       ]
-- META     }
-- META   }
-- META }

-- CELL ********************

--issue with 
Overlap Referrals = 
[Active Referrals Awaiting Offers]
+ [Active Referrals Under Offer]
- [Referrals Currently Active]

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--Active Referrals Awaiting Offers: fact_referrals recreated in is_awaiting_offer
Active Referrals Awaiting Offers = 
VAR LatestExportDate =
    MAXX(
        ALL(dim_referral),
        dim_referral[Export Date Clean]
    )

VAR LiveProviderReferralIDs =
    CALCULATETABLE(
        VALUES(fact_referral_offer[referral_id]),
        REMOVEFILTERS(fact_referral_offer),
        fact_referral_offer[is_cancelled] = FALSE(),
        fact_referral_offer[is_closed] = FALSE(),
        fact_referral_offer[is_excluded] = FALSE()
    )

VAR OpenWithinResponseWindowIDs =
    CALCULATETABLE(
        VALUES(dim_referral[referral_id]),
        REMOVEFILTERS(dim_date),
        dim_referral[referral_status] = "OPEN",
        dim_referral[Response Required Date Clean] >= LatestExportDate
    )

VAR ActiveOpenReferralIDs =
    DISTINCT(
        UNION(
            LiveProviderReferralIDs,
            OpenWithinResponseWindowIDs
        )
    )

RETURN
CALCULATE(
    DISTINCTCOUNT(dim_referral[referral_id]),
    REMOVEFILTERS(dim_date),
    dim_referral[referral_status] = "OPEN",   -- ✅ Only OPEN
    TREATAS(
        ActiveOpenReferralIDs,
        dim_referral[referral_id]
    )
)


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select * from gold.fact_referral where is_awaiting_offer = true
--and current_status = 'OPEN'


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

Active Referrals Under Offer = 
VAR AcceptedOffers =
    CALCULATETABLE(
        VALUES(fact_offer[offer_id]),
        fact_offer[Is_Latest_Record] = 1,
        fact_offer[offer_status] = "OFFER_SUCCESSFUL"
    )

VAR ReferralIDs =
    CALCULATETABLE(
        VALUES(fact_referral_offer[referral_id]),
        TREATAS(AcceptedOffers, fact_referral_offer[offer_id])
    )

RETURN
COUNTROWS(
    DISTINCT(AcceptedOffers)
)


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--2nd measure used for overlap

select distinct referral_id from gold.fact_offer
where offer_status = "OFFER_SUCCESSFUL"

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

--3rd measure used for overlap
Referrals Currently Active = 
VAR LatestExportDate =
    MAXX(
        ALL(dim_referral),
        dim_referral[Export Date Clean]
    )

VAR LiveProviderReferralIDs =
    CALCULATETABLE(
        VALUES(fact_referral_offer[referral_id]),
        REMOVEFILTERS(fact_referral_offer),
        fact_referral_offer[is_cancelled] = FALSE(),
        fact_referral_offer[is_closed] = FALSE(),
        fact_referral_offer[is_excluded] = FALSE()
    )

VAR OpenWithinResponseWindowIDs =
    CALCULATETABLE(
        VALUES(dim_referral[referral_id]),
        REMOVEFILTERS(dim_date),
        dim_referral[referral_status] = "OPEN",
        dim_referral[Response Required Date Clean] >= LatestExportDate
    )

VAR ActiveOpenReferralIDs =
    DISTINCT(
        UNION(
            LiveProviderReferralIDs,
            OpenWithinResponseWindowIDs
        )
    )

VAR UnderOfferReferralIDs =
    CALCULATETABLE(
        VALUES(dim_referral[referral_id]),
        REMOVEFILTERS(dim_date),
        dim_referral[referral_status] = "UNDER_OFFER"
    )

VAR CombinedActiveReferralIDs =
    DISTINCT(
        UNION(
            ActiveOpenReferralIDs,
            UnderOfferReferralIDs
        )
    )

RETURN
CALCULATE(
    DISTINCTCOUNT(dim_referral[referral_id]),
    REMOVEFILTERS(dim_date),
    dim_referral[referral_status] IN { "OPEN", "UNDER_OFFER" },
    TREATAS(
        CombinedActiveReferralIDs,
        dim_referral[referral_id]
    )
)

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

from pyspark.sql.functions import concat, lit, col

df = spark.table("gold.fact_referral_provider")
 

(df
 .coalesce(1)
 .write
 .mode("overwrite")
 .option("header", "true")
 .option("quote", "\u0000")
 .csv("Files/fact_referral_provider"))

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

from pyspark.sql.functions import concat, lit, col

df = spark.table("gold.fact_offer")

cols_to_keep = [
    "as_of_date",
    "offer_id",
    "referral_id",
    "provider_id",
    "home_id",
    "offer_submitted_date",
    "offer_reviewed_date",
    "offer_decision_date",
    "offer_status",
    "offer_type",
    "proposed_placement_start_date",
    "estimated_duration_weeks",
    "estimated_weekly_cost",
    "rejection_reason",
    "offer_age_days",
    "days_since_offer_activity",
    "is_draft_missing_dates",
    "is_draft_no_activity",
    "is_awaiting_ipa_creation",
    "is_ipa_pending",
    "is_ipa_completed",
    "export_date",
    "source_export_date",
    "job_run_id",
    "gold_modelled_at"
]

quoted_df = df.select(
    *[
        concat(lit('"'), col(c).cast("string"), lit('"')).alias(c)
        for c in cols_to_keep
    ]
)

(quoted_df
 .coalesce(1)
 .write
 .mode("overwrite")
 .option("header", "true")
 .option("quote", "\u0000")
 .csv("Files/fact_offer_export"))

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select * from gold.fact_offer

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select * from silver.referral_provider 
where referral_id = "44a97e39-3015-486a-9064-26e5ec12bf29"

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

with cte as 
(
    select  distinct referral_id
    FROM silver.referral_provider rp
    where rp.is_cancelled =false
    AND rp.is_closed =false
    AND rp.is_excluded =false
--), max(
--    select max(export_date) max_export
--    from silver.referral  
), cte_ref (
 select distinct referral_id
from silver.referral 
 where response_required_by_date>= '2026-09-19T00:00:00Z' --max.max_export
 and referral_status='open'
), cte_final (
select * from cte a
union all 
select * from cte_ref
), cte_fact
(
    select distinct referral_id 
    from gold.fact_referral r where
    ( is_awaiting_offer = true
    and r.current_status in ( "OPEN")
    )
)
select * from cte_fact a anti join cte_final b on a.referral_id=b.referral_id

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

with cte as 
(
    select  distinct referral_id
    FROM silver.referral_provider rp
    where rp.is_cancelled =false
    AND rp.is_closed =false
    AND rp.is_excluded =false
--), max(
--    select max(export_date) max_export
--    from silver.referral  
), cte_ref (
 select distinct referral_id
from silver.referral 
 where response_required_by_date>= '2026-09-19T00:00:00Z' --max.max_export
 and referral_status='open'
), cte_final (
select * from cte a
union all 
select * from cte_ref
)
select * from cte_final a
inner join gold.fact_referral r on a.referral_id=r.referral_id
where r.current_status in ( "OPEN", "UNDER_OFFER" )


-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select * from gold.fact_referral
where is_open = TRUE
and current_status = "UNDER_OFFER"

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

with cte as (

select distinct referral_id, 'fact_referral' from gold.fact_referral
where is_awaiting_offer = TRUE


UNION ALL
select distinct referral_id,'fact_offer'  from gold.fact_offer
where offer_status = "OFFER_SUCCESSFUL"
)

select distinct referral_id from cte

-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }

-- CELL ********************

select * from
(select distinct referral_id from gold.fact_referral
where is_open = TRUE
and current_status = "UNDER_OFFER") a
inner join 
(select distinct referral_id from gold.fact_referral
where is_awaiting_offer = TRUE
and is_open = TRUE) b on a.referral_id=b.referral_id



-- METADATA ********************

-- META {
-- META   "language": "sparksql",
-- META   "language_group": "synapse_pyspark"
-- META }
