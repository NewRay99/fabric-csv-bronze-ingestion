# Mission Control job-to-step alignment

This package extends the SEM-02 repaired project with the job-run and
job-step semantic contract required by the Mission Control wireframe.

## Added to the semantic model

- `rpt_job_run_summary`
- `rpt_job_step_timing`
- active, single-direction `job_run_id` relationships from the job summary to
  job steps and existing pipeline-run detail
- `cfg_pipeline_run[job_run_id]`
- 20 job, step, error and selected-or-latest measures in
  `_MissionControl_Measures`

Run `00_setup_cfg` before refreshing this model so the two materialised Lake
views exist. The existing report pages were not redesigned in source JSON;
build the historical Gantt and same-page step table in Power BI Desktop using
the field mapping in
`client documentation/04_Data_and_Reporting/MISSION_CONTROL_SEMANTIC_MODEL_DAX_BUILD_GUIDE.md`.

The original SEM-02 automatic date-table repair remains intact: automatic
time intelligence stays disabled and no generated local date tables or source
column variations were reintroduced.
