# Explorer and provider detail changes

Updated 3 October 2026.

## Edited project

`C:\repos\BCT\fabric-csv-bronze-ingestion\project X\reports\WIP\SM WMPP v16 updated WIP`

This is the newer WIP project containing `dim_provider (offer)` and `dim_provider_home (offer)`. The older copy under `reports\client-deliverables` and the WIP ZIP were not changed.

Original copies of touched files are in:

`C:\repos\BCT\fabric-csv-bronze-ingestion\project X\reports\WIP\_review\explorer-scope-20261003-171523`

`EXPLORER_SCOPE_REPAIR.json` records the touched files and original checksums. No cache, source queries, credentials or security roles were changed. Nothing was published.

## Explorer behaviour

- Provider Explorer starts from the canonical `dim_provider` directory. Providers do not need an offer or a home to appear. An explicit home filter or journey-stage filter can narrow this directory.
- Provider search and selected provider rows filter the KPI list and activity tables. Counts use distinct offer, assignment, referral, message and IPA keys, rather than counting repeated display rows.
- The provider KPI list includes providers, providers without offers, homes, registered beds, offer records, offers made, drafts, accepted and pending offers, acceptance rate, assigned referrals, assignments, messages, qualifying responses, response rate, response time, IPAs, provider-signed IPAs and completed IPAs.
- Offers made excludes drafts and missing statuses. Total offer records is available separately. Messages include both directions and do not represent evidence of browsing.
- Referral Explorer starts from `fact_referral`, including referrals with no offers. It has visible referral ID/person search, its own KPI list, and optional offer-status/activity filters with a `(No offers)` choice.
- Referral KPIs include referrals, open, open overdue, closed, with/without offers, offer coverage, offer records, accepted offers, assignments, messages, IPAs and completed IPAs.
- Existing navigation assets, themes and journey selection controls were retained. Explorer pages remain full-width scrolling pages.

## Detail pages and homes

Provider Detail drills through the canonical provider ID. It includes the same provider KPI list, all registered homes for the selected provider, per-home offer counts, existing activity sections and all available Gold monthly provider metric fields. Homes with no offers remain visible. Missing registered-bed data is left blank, not treated as zero or available capacity.

Referral Detail drills through referral ID and includes the referral KPI list. The existing offer-home visual references were corrected to the actual offer-role home table.

## Monthly provider metrics

The monthly table preserves provider, assignment month and security-scope grain. It displays response opportunities, qualifying responses, submitted offers, accepted offers, successful referrals, placements by target date, average response minutes and median response minutes.

Monthly cohort counts are distinct from current activity totals. Rates use summed numerators and denominators. A pre-aggregated monthly median/average is not combined across multiple rows; the corresponding summary measure is blank unless one monthly row is selected. Activity-level average/median response measures use assignment-level elapsed minutes.

## Loading and acceptance checks

These are saved project-file changes. Desktop rendering, DAX execution and live-data reconciliation have not been verified: the local Desktop capture timed out. Do not save a stale open Desktop session over these files. If Desktop offers **Apply external changes**, use it after safeguarding any unsaved work; otherwise reopen the saved PBIP after safeguarding unsaved work.

Check the following with the loaded data before delivery:

1. A provider without offers, including one without homes, appears with no activity filter applied.
2. A message-only provider shows its messages and zero offer records.
3. Provider search and multi-selection produce distinct counts for exactly the selected providers.
4. Provider drillthrough works without offers and lists all that provider's homes. Per-home offer counts match the offer's recorded home ID.
5. Referrals without offers appear without an activity filter and when `(No offers)` is selected. Their other recorded activity remains available.
6. Monthly rows reconcile to the Gold table at provider/month/security-scope grain.
7. Journey, navigation and expandable-filter bookmarks retain their intended display states. Existing security roles still produce the expected restricted results.

Automated checks cover generated scope logic and saved field references; they do not replace these Desktop/data checks.
