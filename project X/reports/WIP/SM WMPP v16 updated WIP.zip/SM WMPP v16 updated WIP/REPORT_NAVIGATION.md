# WMPP report navigation

Updated 27 September 2026. Open `SM_WMPP_v16.pbip` in this folder. These changes are saved locally in its attached report; nothing has been published or refreshed.

## Current correction: native icons, neutral wallpaper and title-case labels

The experimental bubble bar is withdrawn. All 128 main buttons once again use the direct native custom-icon configuration with white Lucide artwork on separate 66px coral circles. The 16 connecting orange rails are hidden and their resources retained for recovery; the captions beneath the buttons are visible. No fill-image state is required to display the icons. Dropdown actions and white surrounds are retained.

The owner screenshot also showed orange outside the canvas. All 33 pages now explicitly use `#F8F5F1` for wallpaper, matching the canvas and theme defaults. Page names and guide suffixes are title case, preserving WMPP and IPA. The original referral detail view is labelled `Referral Single View (Original)` to avoid duplicate names. Internal page IDs, bookmarks, queries and filters are unchanged.

Backup: `../_review/menu-correction-20260927-202435/`; inventory: `MENU_CORRECTION.json`. The one-off configuration check failed before correction (128 disabled direct icons, 16 visible rails, 31 non-neutral wallpaper configurations and 23 page names requiring case changes), then passed. Microsoft schema validation passed for 549 changed report definitions and four current themes. This is not Desktop visual acceptance and no semantic/report-version pytest suite was added.

Reopen the saved project to inspect the icons, neutral outer background and names. Do not save an older open Desktop session over these changes. The previous bubble implementation remains documented below as history only.

## Superseded design: horizontal bubble bar

All 16 main pages now share a horizontal coral rail with white Lucide icon bubbles. The current section has a blush capsule; hovering expands a rounded coral highlight down around the icon and its always-visible native label. This supersedes the separate circular buttons described in the historical entries below. The effect is a native fill-image state change, not continuous animation.

The 128 button actions and existing menu bookmarks are unchanged. Referral, Offer, Provider and Performance menus still open only their own subpages. The dropdown rows on the added pages have moved down 14px to clear the expanded bubbles. Hidden guide-page navigation, filters, chart queries, model files and report content are unchanged. Superseded standalone captions remain hidden and recoverable; captions are now part of the clickable native button.

The master `WMPP_Theme.json`, both template copies and the embedded theme include a `WMPP Bubble Navigation` preset. The 32 SVG state resources are embedded and also saved under `assets/brand-pack/icons/navigation-bubbles` at the Project X root. No new colours were introduced. Importing the theme alone does not install navigation assets or actions.

Backup: `../_review/bubble-navigation-20260927-201804/`. Implementation inventory: `BUBBLE_NAVIGATION.json`. Microsoft schema validation passed for 741 changed report definitions and four custom themes. Non-navigation report definitions, bookmarks and semantic-model files were checked unchanged; no report-version/semantic pytest suite was added or run.

**Desktop acceptance is still outstanding:** reopen the saved PBIP, inspect labels and hover states, then Ctrl+click each menu group and its Close entry. Confirm the current section is highlighted and filters remain unchanged. These are saved-file and schema checks, not a claim of successful Desktop rendering.

## Menu

A compact row of original-style circular buttons connects all 16 main pages. The earlier two-row menu has been replaced. The active area is highlighted; full captions sit below the abbreviated buttons. Original page names remain capitalised.

All 128 main navigation buttons now explicitly use the original report's native oval shape definition (`tileShape: oval`, `roundEdge: 84L`) with a state selector for default, hover, selected and disabled states. Each retains equal 66-pixel width and height. The earlier unscoped shape entry is replaced; dropdown rows, surrounds, actions, captions and positions are unchanged. Original button files are backed up under `../_review/circular-navigation-20260927-154439/`. Saved-file checks confirm that only these shape definitions changed; Desktop rendering remains unverified.

- `HO` Home, `DO` Draft offers, `IO` IPAs and `RM` Requirements open their pages directly.
- `R` Referrals, `OO` Offers, `PR` Providers and `PF` Performance reveal only their own related pages in a dropdown below the navigation.
- Opening another category closes the previous dropdown. Each dropdown has a Close menu entry. Selecting a destination closes the menu overlays and opens that page.
- On the original branded overview pages, the circles occupy the original header navigation area; the added 104-pixel menu band is removed. Pages without that header retain a dedicated navigation band so their titles and charts are not covered when menus are closed.
- Expanded dropdowns temporarily overlay the content below; they are not always-visible extra rows. Close the menu to inspect that content.
- Each open dropdown now has a continuous white surround: a rounded panel with 12-pixel outer padding, connected to a white surround behind its circular main button. The yellow annotation in the reference was a markup guide only; no yellow is used. The panel has the existing subtle rose-grey shadow. These editable native shapes open/close with their own dropdown and remain hidden otherwise; main buttons, captions and submenu rows are unchanged.

| Area | Pages |
| --- | --- |
| Home | WMPP HOMEPAGE |
| Referrals | REFERRALS; REFERRAL SINGLE VIEW (original); Referral Single View (new explorer); Referral Geography; Referral Snapshots; REFERRAL DETAIL (DRILLTHROUGH) |
| Offers | OFFERS OVERVIEW; DRAFT OFFERS; Offer Locations |
| Providers | PROVIDER SINGLE VIEW; Provider & Placement Supply |
| IPAs | IPA OVERVIEW |
| Performance | Board Dashboard; Target & Urgency Performance |
| Requirements | REQUIREMENT MATRIX OVERVIEW |

The menu uses bookmarks scoped only to its own dropdown controls, with Data disabled. Open/close actions also disable Current page; destination actions change the page and hide dropdowns. No data selection is captured by these menu bookmarks. This follows Microsoft's [selected-visual bookmark guidance](https://learn.microsoft.com/en-us/power-bi/create-reports/desktop-bookmarks).

Navigating to a detail page does not select a record or automatically pass the current visual selection. Use the existing drillthrough action to carry referral context, or use the destination's search/filter controls. Confirm one referral or provider is selected before interpreting individual detail. In Power BI Desktop edit mode, follow action buttons with Ctrl+click.

## Original referral pages restored

The original `REFERRALS` and `REFERRAL SINGLE VIEW` pages from `reports/current/WMPP v16/RPT WMPP v16/WMPP_DASHBOARD_v16.Report` are restored as separate pages. Their former page IDs had been reused by the new geography and referral explorer pages; those newer pages are retained.

The restored pages preserve source queries, visual filters, groups and interactions. Required embedded resources and the original referral filter-panel bookmarks were copied with separate identifiers. They use the current plain canvas and native panel styling, not the old full-page background skin.

Grouped content moves by its parent container, preserving child positions. Superseded page-navigation controls are hidden; chart-view, filter-panel and help controls remain. Hidden guide pages retain their existing return links.

## Verification and backup

- All menu bookmark and page destinations resolve; all 64 dropdown-open states show only their category's entries plus Close. Buttons explicitly enable text at the visual level and provide labels for default, hover, selected and disabled states, following the original saved button format.
- The dropdown revision passed Microsoft schema checks; the white-surround follow-up adds only native shape visuals and their visibility entries in existing menu bookmarks. See its backup verification record for the latest checks.
- Restored source visual queries and filters match; semantic-model files are unchanged.
- No semantic-model or report-version pytest suite was created or run.
- The user's supplied screenshot confirms that the referral dropdown text is now visible. The new white surround, other-page rendering, slicer behaviour and drillthrough execution still require Desktop inspection; schema checks do not prove rendering or data correctness. Earlier Desktop capture failed twice (FrameArrived/window capture timeout).

The original pre-menu report definition and resources are backed up in `../_review/navigation-20260927-143541/`. The complete pre-dropdown definition is in `../_review/dropdown-navigation-20260927-145844/`, with the 168 removed two-row menu visuals retained under `retired-menu/`. Both backups include `verification.json`.

The pre-surround definition is backed up in `../_review/dropdown-surround-20260927-150837/`. This follow-up preserves every existing page/visual file byte-for-byte and leaves semantic-model files unchanged. Only new surround shapes and menu-bookmark entries are added.

Reopen this saved project in Desktop to inspect the revision. Do not save an older open Desktop copy over these file changes. Check that R shows the six referral destinations, OO shows only the three offer destinations, Close hides the list, and date/category selections remain unchanged after opening or closing menus.

## Coral colour revision — 27 September 2026

All 128 main navigation buttons now use `#FB6540`, charcoal labels and lighter
coral hover; a deep-coral outline identifies the current area. The 272 dropdown
row/close buttons use matching coral/soft-coral states with readable dark text.
White dropdown surrounds, native oval geometry, positions, bookmarks and query
definitions are unchanged. The existing card glow and page background remain.

The original rose fills were saved visual overrides, so changing a theme alone
did not update them. Both overrides and the embedded/shared themes have now been
updated. See `assets/brand-pack/WMPP_Brand_Pack.md` at the Project X root for the
extended palette and its contrast rules.

The four pre-change theme files and 400 changed button files are recoverable in
`../_review/coral-palette-20260927-162231/`, with a verification record. Semantic
model files and `WMPP_Theme_v0.json` were hash-checked unchanged. Desktop rendering
still needs inspection after reopening the saved project; do not save an older
open copy over the updated files.

## Lucide navigation icons — 27 September 2026

The main-button initials are replaced by eight white Lucide SVGs on all 16 main
pages (128 buttons). Main-button outlines and borders are disabled, superseding
the deep-coral outline described in the earlier colour revision above. Captions,
tooltips, existing coral fills, positions, circular shapes and bookmark actions
are preserved. Dropdown rows and the separate Filters control are unchanged.

Native button custom icons are used, with a 32px icon-size setting and explicit
default/hover/selected/disabled states. No image overlays intercept clicks.
Resources are embedded in the report; `LUCIDE_NAVIGATION_SOURCES.json` and
`LUCIDE_LICENSE.txt` in this project root provide audit/licence details. Master
assets and unmodified source SVGs are in `assets/brand-pack/icons` at Project X root.

Prior button files, report resource registration and themes are backed up in
`../_review/lucide-navigation-20260927-164358/`. Saved-file checks preserve model
and bookmark contents; Desktop rendering remains unverified. Reopen the saved
project without overwriting it from an older open Desktop session.

## Future edits

Treat navigation as the final report assembly step. Earlier whole-page layout/style builders contain fixed coordinates and may overwrite menus or mis-handle restored grouped visuals. Do not run them directly over this assembled delivery. The migrations `project X/tools/connect_wmpp_report_pages.py` and `project X/tools/use_wmpp_dropdown_navigation.py` intentionally refuse a second application; they are not in-place repeatable styling commands.
